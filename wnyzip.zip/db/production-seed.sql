--
-- PostgreSQL database dump
--

\restrict ofSGjinUa55UGzz0FEw14sjMdH23SgZgYeAoIhBMOYwXELdIlsJfjZbcjqreP7t

-- Dumped from database version 16.10
-- Dumped by pg_dump version 16.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Data for Name: coupons; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.coupons (id, restaurant_id, title, code, description, discount_percent, valid_until, is_active, max_redemptions, deal_type) FROM stdin;
35	154	Free appetizer	\N	\N	\N	2026-04-11	t	100	flat_deal
\.


--
-- Data for Name: discount_windows; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.discount_windows (id, restaurant_id, day_of_week, start_time, end_time, discount_percent, label, is_active) FROM stdin;
1	154	5	17:00	20:00	20	Friday Happy Hour(s) 	t
2	170	1	17:00	20:00	25	Mangia Mondays	t
\.


--
-- Data for Name: restaurants; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.restaurants (id, name, description, cuisine, neighborhood, address, phone, email, image_url, price_range, capacity, is_active, created_at, is_featured, sort_order) FROM stdin;
1	26 Allen	\N	American	Allentown	26 Allen St, Buffalo, NY 14202	\N	\N	https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=800&q=80	$$	60	t	2026-04-01 17:45:57.246427	f	0
3	911 Tavern	\N	Bar & Grill	South Buffalo	911 Abbott Rd, Buffalo, NY 14220	\N	\N	https://images.unsplash.com/photo-1525268323446-0505b6fe7778?w=800&q=80	$	60	t	2026-04-01 17:45:57.246427	f	0
7	Andale Tequila Bar	\N	Mexican	Allentown	226 Allen St, Buffalo, NY 14201	\N	\N	https://images.unsplash.com/photo-1565299585323-38d6b0865b47?w=800&q=80	$$	60	t	2026-04-01 17:45:57.246427	f	0
8	Babeville Music Venue	\N	Venue & Bar	Allentown	341 Delaware Ave, Buffalo, NY 14202	\N	\N	https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=800&q=80	$$	60	t	2026-04-01 17:45:57.246427	f	0
9	Bacchus Wine Bar	\N	Wine Bar & European	Allentown	56 W Chippewa St, Buffalo, NY 14202	\N	\N	https://images.unsplash.com/photo-1510812431401-41d2bd2722f3?w=800&q=80	$$$	60	t	2026-04-01 17:45:57.246427	f	0
10	Bada Bing	\N	Italian	North Buffalo	Buffalo, NY	\N	\N	https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=800&q=80	$$	60	t	2026-04-01 17:45:57.246427	f	0
11	Bally Hoo	\N	Bar & American	Elmwood Village	Buffalo, NY	\N	\N	https://images.unsplash.com/photo-1525268323446-0505b6fe7778?w=800&q=80	$	60	t	2026-04-01 17:45:57.246427	f	0
12	Banshee Irish Pub	\N	Irish Pub	Downtown	Buffalo, NY	\N	\N	https://images.unsplash.com/photo-1525268323446-0505b6fe7778?w=800&q=80	$	60	t	2026-04-01 17:45:57.246427	f	0
13	Barrel Factory	\N	Venue & Bar	Old First Ward	65 Vandalia St, Buffalo, NY 14204	\N	\N	https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=800&q=80	$$	60	t	2026-04-01 17:45:57.246427	f	0
14	Bella Ciao	\N	Italian	Elmwood Village	Buffalo, NY	\N	\N	https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=800&q=80	$$	60	t	2026-04-01 17:45:57.246427	f	0
15	Bellini's Bistro	\N	Italian	North Buffalo	Buffalo, NY	\N	\N	https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=800&q=80	$$	60	t	2026-04-01 17:45:57.246427	f	0
16	Belt Line Brew & Kitchen	\N	Brewery	Elmwood Village	Buffalo, NY	\N	\N	https://images.unsplash.com/photo-1528698827591-e19ccd7bc23d?w=800&q=80	$$	60	t	2026-04-01 17:45:57.246427	f	0
17	Betty's Buffalo	\N	Brunch & American	Elmwood Village	370 Virginia St, Buffalo, NY 14201	\N	\N	https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=800&q=80	$$	60	t	2026-04-01 17:45:57.246427	f	0
18	Bflo Pizza Bistro	\N	Pizza	Downtown	Buffalo, NY	\N	\N	https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=800&q=80	$	60	t	2026-04-01 17:45:57.246427	f	0
19	Big Big Table	\N	American	Elmwood Village	Buffalo, NY	\N	\N	https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=800&q=80	$$	60	t	2026-04-01 17:45:57.246427	f	0
20	Big Ditch Brewing	\N	Brewery	Larkinville	55 E Huron St, Buffalo, NY 14203	\N	\N	https://images.unsplash.com/photo-1528698827591-e19ccd7bc23d?w=800&q=80	$$	60	t	2026-04-01 17:45:57.246427	f	0
21	Billy Club	\N	Bar & American	Allentown	Buffalo, NY	\N	\N	https://images.unsplash.com/photo-1525268323446-0505b6fe7778?w=800&q=80	$	60	t	2026-04-01 17:45:57.246427	f	0
22	Blue Cave	\N	Bar & American	Downtown	Buffalo, NY	\N	\N	https://images.unsplash.com/photo-1525268323446-0505b6fe7778?w=800&q=80	$	60	t	2026-04-01 17:45:57.246427	f	0
23	Bratts Hill	\N	American	North Buffalo	Buffalo, NY	\N	\N	https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=800&q=80	$$	60	t	2026-04-01 17:45:57.246427	f	0
24	Broadway Market	\N	Food Hall & Market	Broadway-Fillmore	999 Broadway, Buffalo, NY 14212	\N	\N	https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=800&q=80	$	60	t	2026-04-01 17:45:57.246427	f	0
25	Buffalo Bandits	\N	Sports & Entertainment	Downtown	1 James D Griffin Plaza, Buffalo, NY 14203	\N	\N	https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=800&q=80	$$	60	t	2026-04-01 17:45:57.246427	f	0
26	Buffalo Bisons	\N	Sports & Entertainment	Downtown	1 James D Griffin Plaza, Buffalo, NY 14203	\N	\N	https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=800&q=80	$$	60	t	2026-04-01 17:45:57.246427	f	0
27	Buffalo ChopHouse	\N	Steakhouse	Downtown	282 Franklin St, Buffalo, NY 14202	\N	\N	https://images.unsplash.com/photo-1558030006-450675393462?w=800&q=80	$$$$	60	t	2026-04-01 17:45:57.246427	f	0
28	Buffalo Country Market	\N	Market & American	North Buffalo	Buffalo, NY	\N	\N	https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=800&q=80	$	60	t	2026-04-01 17:45:57.246427	f	0
29	Buffalo Kitchen Club	\N	American	Downtown	Buffalo, NY	\N	\N	https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=800&q=80	$$	60	t	2026-04-01 17:45:57.246427	f	0
30	Buffalo Olde Brewery	\N	Brewery	Old First Ward	Buffalo, NY	\N	\N	https://images.unsplash.com/photo-1528698827591-e19ccd7bc23d?w=800&q=80	$$	60	t	2026-04-01 17:45:57.246427	f	0
2	500 Pearl		American	Downtown	500 Pearl St, Buffalo, NY 14202	\N	\N	https://500pearlbuffalo.com/wp-content/uploads/2024/09/cropped-500_200px-white.webp	$$	60	t	2026-04-01 17:45:57.246427	t	0
4	Aguacates Bar and Grill	\N	Mexican	West Side	Buffalo, NY	\N	\N	https://images.unsplash.com/photo-1565299585323-38d6b0865b47?w=800&q=80	$$	60	t	2026-04-01 17:45:57.246427	t	0
5	Allen Burger Venture	\N	Burgers	Allentown	175 Allen St, Buffalo, NY 14201	\N	\N	https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=800&q=80	$$	60	t	2026-04-01 17:45:57.246427	t	0
6	Anchor Bar Buffalo	\N	Wings & American	Downtown	1047 Main St, Buffalo, NY 14209	\N	\N	https://images.unsplash.com/photo-1527477396000-e27163b481c2?w=800&q=80	$$	60	t	2026-04-01 17:45:57.246427	t	0
31	Buffalo Tap House	\N	Bar & American	Downtown	Buffalo, NY	\N	\N	https://images.unsplash.com/photo-1525268323446-0505b6fe7778?w=800&q=80	$	60	t	2026-04-01 17:46:01.22441	f	0
32	Buffalo Water Front	\N	American & Seafood	Canalside	329 Scott St, Buffalo, NY 14204	\N	\N	https://images.unsplash.com/photo-1615141982883-c7ad0e69fd62?w=800&q=80	$$$	60	t	2026-04-01 17:46:01.22441	f	0
33	Burning Buffalo	\N	BBQ	Elmwood Village	Buffalo, NY	\N	\N	https://images.unsplash.com/photo-1544025162-d76694265947?w=800&q=80	$$	60	t	2026-04-01 17:46:01.22441	f	0
34	Cafe 59	\N	Cafe & American	Allentown	Buffalo, NY	\N	\N	https://images.unsplash.com/photo-1501339847302-ac426a4a7cbb?w=800&q=80	$	60	t	2026-04-01 17:46:01.22441	f	0
35	Casa Azul	\N	Mexican	Allentown	Buffalo, NY	\N	\N	https://images.unsplash.com/photo-1565299585323-38d6b0865b47?w=800&q=80	$$	60	t	2026-04-01 17:46:01.22441	f	0
36	Charlie's Boat Yard	\N	Bar & American	Canalside	Buffalo, NY	\N	\N	https://images.unsplash.com/photo-1525268323446-0505b6fe7778?w=800&q=80	$$	60	t	2026-04-01 17:46:01.22441	f	0
37	Chef's Buffalo	\N	American	Downtown	291 Seneca St, Buffalo, NY 14204	\N	\N	https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=800&q=80	$$	60	t	2026-04-01 17:46:01.22441	f	0
38	Clubhouse @ Seneca 1	\N	American	Seneca Street	Buffalo, NY	\N	\N	https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=800&q=80	$$	60	t	2026-04-01 17:46:01.22441	f	0
39	Cluck Cluck Moo Moo	\N	American	Elmwood Village	Buffalo, NY	\N	\N	https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=800&q=80	$	60	t	2026-04-01 17:46:01.22441	f	0
40	Cobblestone Bar	\N	Bar & American	Cobblestone District	68 Perry St, Buffalo, NY 14203	\N	\N	https://images.unsplash.com/photo-1525268323446-0505b6fe7778?w=800&q=80	$	60	t	2026-04-01 17:46:01.22441	f	0
41	Coco Bar & Bistro	\N	Bistro	Elmwood Village	Buffalo, NY	\N	\N	https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=800&q=80	$$	60	t	2026-04-01 17:46:01.22441	f	0
42	Coles	\N	American	Elmwood Village	1104 Elmwood Ave, Buffalo, NY 14222	\N	\N	https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=800&q=80	$$	60	t	2026-04-01 17:46:01.22441	f	0
43	Colter Bay	\N	American	North Buffalo	Buffalo, NY	\N	\N	https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=800&q=80	$$	60	t	2026-04-01 17:46:01.22441	f	0
44	Community Beer Works	\N	Brewery	Downtown	520 7th St, Buffalo, NY 14201	\N	\N	https://images.unsplash.com/photo-1528698827591-e19ccd7bc23d?w=800&q=80	$$	60	t	2026-04-01 17:46:01.22441	f	0
45	Crenshaw's Chik & Waffles	\N	Soul Food	East Side	Buffalo, NY	\N	\N	https://images.unsplash.com/photo-1626082929543-3acf4e956cce?w=800&q=80	$	60	t	2026-04-01 17:46:01.22441	f	0
46	Daniela Cafe	\N	Cafe & Italian	Elmwood Village	Buffalo, NY	\N	\N	https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=800&q=80	$	60	t	2026-04-01 17:46:01.22441	f	0
47	Days Park Tavern	\N	Bar & American	Allentown	Buffalo, NY	\N	\N	https://images.unsplash.com/photo-1525268323446-0505b6fe7778?w=800&q=80	$	60	t	2026-04-01 17:46:01.22441	f	0
48	Dinosaur BBQ Buffalo	\N	BBQ	Larkinville	301 Franklin St, Buffalo, NY 14202	\N	\N	https://images.unsplash.com/photo-1544025162-d76694265947?w=800&q=80	$$	60	t	2026-04-01 17:46:01.22441	f	0
49	Ditondo	\N	Italian	North Buffalo	Buffalo, NY	\N	\N	https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=800&q=80	$$$	60	t	2026-04-01 17:46:01.22441	f	0
50	Don Tequila Mexican	\N	Mexican	West Side	Buffalo, NY	\N	\N	https://images.unsplash.com/photo-1565299585323-38d6b0865b47?w=800&q=80	$$	60	t	2026-04-01 17:46:01.22441	f	0
51	DTour Bar & Grill	\N	Bar & Grill	Downtown	Buffalo, NY	\N	\N	https://images.unsplash.com/photo-1525268323446-0505b6fe7778?w=800&q=80	$	60	t	2026-04-01 17:46:01.22441	f	0
52	Eckl's @ Larkin	\N	American	Larkinville	Buffalo, NY	\N	\N	https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=800&q=80	$$	60	t	2026-04-01 17:46:01.22441	f	0
53	Elmwood Bidwell Farmers Market	\N	Market	Elmwood Village	Bidwell Pkwy, Buffalo, NY 14222	\N	\N	https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=800&q=80	$	60	t	2026-04-01 17:46:01.22441	f	0
54	Faso's Italian	\N	Italian	South Buffalo	Buffalo, NY	\N	\N	https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=800&q=80	$$	60	t	2026-04-01 17:46:01.22441	f	0
55	Fat Bobs	\N	BBQ	Allentown	41 Virginia Pl, Buffalo, NY 14202	\N	\N	https://images.unsplash.com/photo-1544025162-d76694265947?w=800&q=80	$$	60	t	2026-04-01 17:46:01.22441	f	0
56	Flying Bison	\N	Brewery	Larkinville	840 Seneca St, Buffalo, NY 14210	\N	\N	https://images.unsplash.com/photo-1528698827591-e19ccd7bc23d?w=800&q=80	$$	60	t	2026-04-01 17:46:01.22441	f	0
57	Frankie Primos	\N	Italian	North Buffalo	Buffalo, NY	\N	\N	https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=800&q=80	$$	60	t	2026-04-01 17:46:01.22441	f	0
58	Franks Gourmet Dogs	\N	Hot Dogs	Elmwood Village	Buffalo, NY	\N	\N	https://images.unsplash.com/photo-1612392166886-ee8475b03af2?w=800&q=80	$	60	t	2026-04-01 17:46:01.22441	f	0
59	Frizzy's Bar	\N	Bar & American	Black Rock	Buffalo, NY	\N	\N	https://images.unsplash.com/photo-1525268323446-0505b6fe7778?w=800&q=80	$	60	t	2026-04-01 17:46:01.22441	f	0
60	Froth Brewing	\N	Brewery	Elmwood Village	Buffalo, NY	\N	\N	https://images.unsplash.com/photo-1528698827591-e19ccd7bc23d?w=800&q=80	$$	60	t	2026-04-01 17:46:01.22441	f	0
61	Garage Bar & Restaurant	\N	Bar & American	Allentown	Buffalo, NY	\N	\N	https://images.unsplash.com/photo-1525268323446-0505b6fe7778?w=800&q=80	$	60	t	2026-04-01 17:46:05.356279	f	0
62	Giacobbi's Cucina Citta	\N	Italian	Downtown	Buffalo, NY	\N	\N	https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=800&q=80	$$$	60	t	2026-04-01 17:46:05.356279	f	0
63	Graylynn	\N	American	Elmwood Village	Buffalo, NY	\N	\N	https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=800&q=80	$$	60	t	2026-04-01 17:46:05.356279	f	0
64	Grotto	\N	Bar & American	Allentown	Buffalo, NY	\N	\N	https://images.unsplash.com/photo-1525268323446-0505b6fe7778?w=800&q=80	$	60	t	2026-04-01 17:46:05.356279	f	0
65	Gypsy Parlor	\N	American	Allentown	376 Grant St, Buffalo, NY 14213	\N	\N	https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=800&q=80	$$	60	t	2026-04-01 17:46:05.356279	f	0
66	Happy Swallow 1987	\N	Bar & American	Allentown	Buffalo, NY	\N	\N	https://images.unsplash.com/photo-1525268323446-0505b6fe7778?w=800&q=80	$	60	t	2026-04-01 17:46:05.356279	f	0
67	Hartmans Distilling	\N	Distillery & Bar	Downtown	Buffalo, NY	\N	\N	https://images.unsplash.com/photo-1525268323446-0505b6fe7778?w=800&q=80	$$	60	t	2026-04-01 17:46:05.356279	f	0
68	Hofbrauhaus Buffalo	\N	German	Larkinville	Buffalo, NY	\N	\N	https://images.unsplash.com/photo-1555939594-58d7cb561ad1?w=800&q=80	$$	60	t	2026-04-01 17:46:05.356279	f	0
69	House of Charm	\N	Bar & American	Allentown	Buffalo, NY	\N	\N	https://images.unsplash.com/photo-1525268323446-0505b6fe7778?w=800&q=80	$	60	t	2026-04-01 17:46:05.356279	f	0
70	Howling Rooster	\N	American	Elmwood Village	Buffalo, NY	\N	\N	https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=800&q=80	$$	60	t	2026-04-01 17:46:05.356279	f	0
71	Hutch's	\N	American Fine Dining	Elmwood Village	1375 Delaware Ave, Buffalo, NY 14209	\N	\N	https://images.unsplash.com/photo-1414235077428-338989a2e8c0?w=800&q=80	$$$	60	t	2026-04-01 17:46:05.356279	f	0
72	Hydraulic Hearth	\N	Pizza & American	Larkinville	716 Swan St, Buffalo, NY 14210	\N	\N	https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=800&q=80	$$	60	t	2026-04-01 17:46:05.356279	f	0
73	India Gate	\N	Indian	Elmwood Village	Buffalo, NY	\N	\N	https://images.unsplash.com/photo-1601050690597-df0568f70950?w=800&q=80	$$	60	t	2026-04-01 17:46:05.356279	f	0
74	Iron Tail Tavern	\N	Bar & American	South Buffalo	Buffalo, NY	\N	\N	https://images.unsplash.com/photo-1525268323446-0505b6fe7778?w=800&q=80	$	60	t	2026-04-01 17:46:05.356279	f	0
75	Iron Works Buffalo	\N	American	Downtown	Buffalo, NY	\N	\N	https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=800&q=80	$$	60	t	2026-04-01 17:46:05.356279	f	0
76	Jam Parkside	\N	American	North Buffalo	Buffalo, NY	\N	\N	https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=800&q=80	$$	60	t	2026-04-01 17:46:05.356279	f	0
77	Just Vino	\N	Wine Bar	Elmwood Village	Buffalo, NY	\N	\N	https://images.unsplash.com/photo-1510812431401-41d2bd2722f3?w=800&q=80	$$	60	t	2026-04-01 17:46:05.356279	f	0
78	K Dara Noodle Bar	\N	Asian	Elmwood Village	Buffalo, NY	\N	\N	https://images.unsplash.com/photo-1569050467447-ce54b3bbc37d?w=800&q=80	$$	60	t	2026-04-01 17:46:05.356279	f	0
79	La Divina	\N	Italian	Allentown	Buffalo, NY	\N	\N	https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=800&q=80	$$	60	t	2026-04-01 17:46:05.356279	f	0
80	La Nova Pizzaria	\N	Pizza	West Side	371 W Ferry St, Buffalo, NY 14213	\N	\N	https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=800&q=80	$$	60	t	2026-04-01 17:46:05.356279	f	0
81	Lambardo's Restaurant	\N	Italian	South Buffalo	Buffalo, NY	\N	\N	https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=800&q=80	$$	60	t	2026-04-01 17:46:05.356279	f	0
82	Larkin Ville	\N	Venue & American	Larkinville	745 Seneca St, Buffalo, NY 14210	\N	\N	https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=800&q=80	$$	60	t	2026-04-01 17:46:05.356279	f	0
83	Las Puertas	\N	Mexican	Allentown	Buffalo, NY	\N	\N	https://images.unsplash.com/photo-1565299585323-38d6b0865b47?w=800&q=80	$$	60	t	2026-04-01 17:46:05.356279	f	0
84	LaVerdad Cafe Deli	\N	Latin & Cafe	West Side	Buffalo, NY	\N	\N	https://images.unsplash.com/photo-1565299585323-38d6b0865b47?w=800&q=80	$	60	t	2026-04-01 17:46:05.356279	f	0
85	Left Bank	\N	American & French	Elmwood Village	511 Rhode Island St, Buffalo, NY 14213	\N	\N	https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=800&q=80	$$$	60	t	2026-04-01 17:46:05.356279	f	0
86	Lexington Coop	\N	American	Elmwood Village	807 Elmwood Ave, Buffalo, NY 14222	\N	\N	https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=800&q=80	$$	60	t	2026-04-01 17:46:05.356279	f	0
87	Liberty Hound	\N	American & Seafood	Canalside	1 Naval Park Cove, Buffalo, NY 14202	\N	\N	https://images.unsplash.com/photo-1615141982883-c7ad0e69fd62?w=800&q=80	$$	60	t	2026-04-01 17:46:05.356279	f	0
88	Lunch Box Buffalo	\N	American	Downtown	Buffalo, NY	\N	\N	https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=800&q=80	$	60	t	2026-04-01 17:46:05.356279	f	0
89	Magic Bear Beer	\N	Brewery	Black Rock	Buffalo, NY	\N	\N	https://images.unsplash.com/photo-1528698827591-e19ccd7bc23d?w=800&q=80	$$	60	t	2026-04-01 17:46:05.356279	f	0
90	Marble Rye	\N	American	Elmwood Village	Buffalo, NY	\N	\N	https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=800&q=80	$$	60	t	2026-04-01 17:46:05.356279	f	0
91	Marco's Italian	\N	Italian	North Buffalo	Buffalo, NY	\N	\N	https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=800&q=80	$$	60	t	2026-04-01 17:46:09.167731	f	0
92	Mcpartlan's Corner	\N	Irish Pub	Elmwood Village	Buffalo, NY	\N	\N	https://images.unsplash.com/photo-1525268323446-0505b6fe7778?w=800&q=80	$	60	t	2026-04-01 17:46:09.167731	f	0
93	Merry Shelly	\N	Bar & American	Allentown	Buffalo, NY	\N	\N	https://images.unsplash.com/photo-1525268323446-0505b6fe7778?w=800&q=80	$	60	t	2026-04-01 17:46:09.167731	f	0
94	Misuta Chows	\N	Asian Fusion	Downtown	Buffalo, NY	\N	\N	https://images.unsplash.com/photo-1569050467447-ce54b3bbc37d?w=800&q=80	$$	60	t	2026-04-01 17:46:09.167731	f	0
95	Mortalis Brewing	\N	Brewery	Allentown	Buffalo, NY	\N	\N	https://images.unsplash.com/photo-1528698827591-e19ccd7bc23d?w=800&q=80	$$	60	t	2026-04-01 17:46:09.167731	f	0
96	Mr Good Bar	\N	Bar & American	Elmwood Village	1 Linwood Ave, Buffalo, NY 14209	\N	\N	https://images.unsplash.com/photo-1525268323446-0505b6fe7778?w=800&q=80	$	60	t	2026-04-01 17:46:09.167731	f	0
97	Mr Sizzles	\N	American	North Buffalo	Buffalo, NY	\N	\N	https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=800&q=80	$	60	t	2026-04-01 17:46:09.167731	f	0
98	Mulligan's Brick Bar	\N	Irish Pub	Allentown	Buffalo, NY	\N	\N	https://images.unsplash.com/photo-1525268323446-0505b6fe7778?w=800&q=80	$	60	t	2026-04-01 17:46:09.167731	f	0
99	Niagara Cafe PR	\N	Puerto Rican	West Side	Buffalo, NY	\N	\N	https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=800&q=80	$	60	t	2026-04-01 17:46:09.167731	f	0
100	Olivers Cuisine	\N	American Fine Dining	Allentown	2095 Delaware Ave, Buffalo, NY 14216	\N	\N	https://images.unsplash.com/photo-1414235077428-338989a2e8c0?w=800&q=80	$$$	60	t	2026-04-01 17:46:09.167731	f	0
101	Osteria 166	\N	Italian	Downtown	166 Franklin St, Buffalo, NY 14202	\N	\N	https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=800&q=80	$$$	60	t	2026-04-01 17:46:09.167731	f	0
102	Panorama on 7	\N	American	Downtown	120 Church St, Buffalo, NY 14202	\N	\N	https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=800&q=80	$$$	60	t	2026-04-01 17:46:09.167731	f	0
103	Park Vue Soul Food	\N	Soul Food	East Side	Buffalo, NY	\N	\N	https://images.unsplash.com/photo-1626082929543-3acf4e956cce?w=800&q=80	$	60	t	2026-04-01 17:46:09.167731	f	0
104	Parkside Meadow	\N	American	North Buffalo	Buffalo, NY	\N	\N	https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=800&q=80	$$	60	t	2026-04-01 17:46:09.167731	f	0
105	Patina 250	\N	American Fine Dining	Downtown	250 Delaware Ave, Buffalo, NY 14202	\N	\N	https://images.unsplash.com/photo-1414235077428-338989a2e8c0?w=800&q=80	$$$	60	t	2026-04-01 17:46:09.167731	f	0
106	Pausa Art House	\N	Italian & Wine	Allentown	19 W Mohawk St, Buffalo, NY 14201	\N	\N	https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=800&q=80	$$	60	t	2026-04-01 17:46:09.167731	f	0
107	Pearl Street	\N	Bar & Grill	Downtown	76 Pearl St, Buffalo, NY 14202	\N	\N	https://images.unsplash.com/photo-1525268323446-0505b6fe7778?w=800&q=80	$$	60	t	2026-04-01 17:46:09.167731	f	0
108	Phat Catz	\N	Bar & American	Downtown	Buffalo, NY	\N	\N	https://images.unsplash.com/photo-1525268323446-0505b6fe7778?w=800&q=80	$	60	t	2026-04-01 17:46:09.167731	f	0
109	Pizza Plant Canalside	\N	Pizza	Canalside	226 Ohio St, Buffalo, NY 14204	\N	\N	https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=800&q=80	$$	60	t	2026-04-01 17:46:09.167731	f	0
110	Place	\N	American	Elmwood Village	Buffalo, NY	\N	\N	https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=800&q=80	$$	60	t	2026-04-01 17:46:09.167731	f	0
111	Pool Club at Sol	\N	Bar & American	Downtown	Buffalo, NY	\N	\N	https://images.unsplash.com/photo-1525268323446-0505b6fe7778?w=800&q=80	$$	60	t	2026-04-01 17:46:09.167731	f	0
112	Public Espresso	\N	Coffee & Cafe	Elmwood Village	765 Elmwood Ave, Buffalo, NY 14222	\N	\N	https://images.unsplash.com/photo-1501339847302-ac426a4a7cbb?w=800&q=80	$	60	t	2026-04-01 17:46:09.167731	f	0
113	Rec Room Buffalo	\N	Bar & Entertainment	Downtown	Buffalo, NY	\N	\N	https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=800&q=80	$$	60	t	2026-04-01 17:46:09.167731	f	0
114	Remedy House	\N	Bar & American	Allentown	Buffalo, NY	\N	\N	https://images.unsplash.com/photo-1525268323446-0505b6fe7778?w=800&q=80	$	60	t	2026-04-01 17:46:09.167731	f	0
115	Resurgence Brewing	\N	Brewery	Black Rock	1250 Niagara St, Buffalo, NY 14213	\N	\N	https://images.unsplash.com/photo-1528698827591-e19ccd7bc23d?w=800&q=80	$$	60	t	2026-04-01 17:46:09.167731	f	0
116	River Works	\N	Bar & Entertainment	Old First Ward	359 Ganson St, Buffalo, NY 14203	\N	\N	https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=800&q=80	$$	60	t	2026-04-01 17:46:09.167731	f	0
117	Roost Buffalo	\N	American	Elmwood Village	Buffalo, NY	\N	\N	https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=800&q=80	$$	60	t	2026-04-01 17:46:09.167731	f	0
118	Rust Belt Bar & Grill	\N	Bar & Grill	Larkinville	Buffalo, NY	\N	\N	https://images.unsplash.com/photo-1525268323446-0505b6fe7778?w=800&q=80	$	60	t	2026-04-01 17:46:09.167731	f	0
119	Sabores De Mi Tierra	\N	Latin	West Side	Buffalo, NY	\N	\N	https://images.unsplash.com/photo-1565299585323-38d6b0865b47?w=800&q=80	$	60	t	2026-04-01 17:46:09.167731	f	0
120	Salty Chefs	\N	American	Elmwood Village	Buffalo, NY	\N	\N	https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=800&q=80	$$	60	t	2026-04-01 17:46:09.167731	f	0
121	Santasiero's Restaurant	\N	Italian	Black Rock	1329 Niagara St, Buffalo, NY 14213	\N	\N	https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=800&q=80	$$	60	t	2026-04-01 17:46:13.142182	f	0
122	Shakespeare in The Park	\N	Entertainment & Venue	Delaware Park	Delaware Park, Buffalo, NY 14222	\N	\N	https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=800&q=80	$	60	t	2026-04-01 17:46:13.142182	f	0
123	Shango Bistro & Wine	\N	American & Wine	Elmwood Village	3260 Main St, Buffalo, NY 14214	\N	\N	https://images.unsplash.com/photo-1510812431401-41d2bd2722f3?w=800&q=80	$$$	60	t	2026-04-01 17:46:13.142182	f	0
124	Sloan Supermarket	\N	Bar & American	Downtown	Buffalo, NY	\N	\N	https://images.unsplash.com/photo-1525268323446-0505b6fe7778?w=800&q=80	$	60	t	2026-04-01 17:46:13.142182	f	0
125	Soho	\N	Bar & American	Allentown	Buffalo, NY	\N	\N	https://images.unsplash.com/photo-1525268323446-0505b6fe7778?w=800&q=80	$	60	t	2026-04-01 17:46:13.142182	f	0
126	Southern Tier Buffalo	\N	Brewery	Canalside	620 Ohio St, Buffalo, NY 14203	\N	\N	https://images.unsplash.com/photo-1528698827591-e19ccd7bc23d?w=800&q=80	$$	60	t	2026-04-01 17:46:13.142182	f	0
127	Southern Junction	\N	Southern & American	East Side	Buffalo, NY	\N	\N	https://images.unsplash.com/photo-1544025162-d76694265947?w=800&q=80	$$	60	t	2026-04-01 17:46:13.142182	f	0
128	Spotted Octopus	\N	Bar & American	Allentown	Buffalo, NY	\N	\N	https://images.unsplash.com/photo-1525268323446-0505b6fe7778?w=800&q=80	$	60	t	2026-04-01 17:46:13.142182	f	0
129	Sully's	\N	Bar & American	South Buffalo	Buffalo, NY	\N	\N	https://images.unsplash.com/photo-1525268323446-0505b6fe7778?w=800&q=80	$	60	t	2026-04-01 17:46:13.142182	f	0
130	Swannie House	\N	Bar & American	Old First Ward	170 Ohio St, Buffalo, NY 14203	\N	\N	https://images.unsplash.com/photo-1525268323446-0505b6fe7778?w=800&q=80	$	60	t	2026-04-01 17:46:13.142182	f	0
131	Tappo Buffalo	\N	Italian & Pizza	Downtown	338 Ellicott St, Buffalo, NY 14203	\N	\N	https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=800&q=80	$$	60	t	2026-04-01 17:46:13.142182	f	0
132	Taqueria Ranchos	\N	Mexican	West Side	Buffalo, NY	\N	\N	https://images.unsplash.com/photo-1565299585323-38d6b0865b47?w=800&q=80	$	60	t	2026-04-01 17:46:13.142182	f	0
133	Ted's Hot Dogs	\N	Hot Dogs	Elmwood Village	2312 Sheridan Dr, Buffalo, NY 14223	\N	\N	https://images.unsplash.com/photo-1612392166886-ee8475b03af2?w=800&q=80	$	60	t	2026-04-01 17:46:13.142182	f	0
134	Templeton Landing	\N	American & Seafood	Canalside	2 Templeton Terrace, Buffalo, NY 14202	\N	\N	https://images.unsplash.com/photo-1615141982883-c7ad0e69fd62?w=800&q=80	$$$	60	t	2026-04-01 17:46:13.142182	f	0
135	Terrace Buffalo	\N	American	Downtown	Buffalo, NY	\N	\N	https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=800&q=80	$$	60	t	2026-04-01 17:46:13.142182	f	0
136	Thirsty Buffalo	\N	Bar & American	North Buffalo	Buffalo, NY	\N	\N	https://images.unsplash.com/photo-1525268323446-0505b6fe7778?w=800&q=80	$	60	t	2026-04-01 17:46:13.142182	f	0
137	Thursdays & Main	\N	Bar & American	Downtown	Buffalo, NY	\N	\N	https://images.unsplash.com/photo-1525268323446-0505b6fe7778?w=800&q=80	$	60	t	2026-04-01 17:46:13.142182	f	0
138	Toutant	\N	Southern & American	Downtown	437 Ellicott St, Buffalo, NY 14203	\N	\N	https://images.unsplash.com/photo-1544025162-d76694265947?w=800&q=80	$$$	60	t	2026-04-01 17:46:13.142182	f	0
139	Town Ball Room	\N	Venue & Bar	Downtown	Buffalo, NY	\N	\N	https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=800&q=80	$$	60	t	2026-04-01 17:46:13.142182	f	0
140	Trattoria Aroma	\N	Italian	Elmwood Village	Buffalo, NY	\N	\N	https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=800&q=80	$$	60	t	2026-04-01 17:46:13.142182	f	0
141	Tudor Lounge	\N	Bar & American	South Buffalo	Buffalo, NY	\N	\N	https://images.unsplash.com/photo-1525268323446-0505b6fe7778?w=800&q=80	$	60	t	2026-04-01 17:46:13.142182	f	0
142	Ulrichs Tavern	\N	German & Bar	Downtown	674 Ellicott St, Buffalo, NY 14203	\N	\N	https://images.unsplash.com/photo-1555939594-58d7cb561ad1?w=800&q=80	$	60	t	2026-04-01 17:46:13.142182	f	0
143	Union Pub	\N	Bar & American	Allentown	Buffalo, NY	\N	\N	https://images.unsplash.com/photo-1525268323446-0505b6fe7778?w=800&q=80	$	60	t	2026-04-01 17:46:13.142182	f	0
144	Vault 237	\N	Bar & American	Downtown	Buffalo, NY	\N	\N	https://images.unsplash.com/photo-1525268323446-0505b6fe7778?w=800&q=80	$$	60	t	2026-04-01 17:46:13.142182	f	0
145	Vice Buffalo	\N	Bar & American	Allentown	Buffalo, NY	\N	\N	https://images.unsplash.com/photo-1525268323446-0505b6fe7778?w=800&q=80	$	60	t	2026-04-01 17:46:13.142182	f	0
146	Vintage Room Buffalo	\N	Wine Bar	Downtown	Buffalo, NY	\N	\N	https://images.unsplash.com/photo-1510812431401-41d2bd2722f3?w=800&q=80	$$	60	t	2026-04-01 17:46:13.142182	f	0
147	Wally's Cafe & Pizza	\N	Pizza & Cafe	South Buffalo	Buffalo, NY	\N	\N	https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=800&q=80	$	60	t	2026-04-01 17:46:13.142182	f	0
148	Waxlight Bar & Vin	\N	Wine Bar	Allentown	64 Chandler St, Buffalo, NY 14207	\N	\N	https://images.unsplash.com/photo-1510812431401-41d2bd2722f3?w=800&q=80	$$	60	t	2026-04-01 17:46:13.142182	f	0
149	Wellington Pub	\N	British Pub	North Buffalo	Buffalo, NY	\N	\N	https://images.unsplash.com/photo-1525268323446-0505b6fe7778?w=800&q=80	$	60	t	2026-04-01 17:46:13.142182	f	0
150	Wiechecs	\N	Polish & American	South Buffalo	Buffalo, NY	\N	\N	https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=800&q=80	$	60	t	2026-04-01 17:46:13.142182	f	0
151	Wonder Coffee House	\N	Coffee & Cafe	Elmwood Village	Buffalo, NY	\N	\N	https://images.unsplash.com/photo-1501339847302-ac426a4a7cbb?w=800&q=80	$	60	t	2026-04-01 17:46:16.987554	f	0
152	Dog & Pony Saloon	\N	Bar & American	Allentown	Buffalo, NY	\N	\N	https://images.unsplash.com/photo-1525268323446-0505b6fe7778?w=800&q=80	$	60	t	2026-04-01 17:46:16.987554	f	0
153	Beacon Grill	\N	American	Elmwood Village	Buffalo, NY	\N	\N	https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=800&q=80	$$	60	t	2026-04-01 17:46:16.987554	f	0
155	American Legion OP	\N	Bar & Grill	Orchard Park	4403 S Buffalo St, Orchard Park, NY 14127	\N	\N	\N	$	60	t	2026-04-02 19:14:24.722135	f	0
156	Big Tree Inn	\N	American	Orchard Park	4259 N Buffalo Rd, Orchard Park, NY 14127	\N	\N	\N	$$	60	t	2026-04-02 19:14:28.603666	f	0
157	Bob O Link Golf	\N	Bar & Grill	Orchard Park	4653 Southwestern Blvd, Orchard Park, NY 14127	\N	\N	\N	$$	60	t	2026-04-02 19:14:32.472838	f	0
158	Buffalo Sports Garden	\N	Sports Bar	Orchard Park	Orchard Park, NY 14127	\N	\N	\N	$$	60	t	2026-04-02 19:14:36.572176	f	0
159	Buffalo's Best Grill	\N	American	Orchard Park	Orchard Park, NY 14127	\N	\N	\N	$	60	t	2026-04-02 19:14:40.663046	f	0
160	Cappelli's Pizzaria	\N	Pizza	Orchard Park	3795 N Buffalo Rd, Orchard Park, NY 14127	\N	\N	\N	$	60	t	2026-04-02 19:14:44.581169	f	0
161	Cork & Vine	\N	Wine Bar	Orchard Park	Orchard Park, NY 14127	\N	\N	\N	$$$	60	t	2026-04-02 19:14:48.503105	f	0
162	Duffs Famous Wings	\N	Wings	Orchard Park	Orchard Park, NY 14127	\N	\N	\N	$	60	t	2026-04-02 19:14:52.44337	f	0
163	First Line Brewing	\N	Brewery	Orchard Park	Orchard Park, NY 14127	\N	\N	\N	$$	60	t	2026-04-02 19:14:56.301989	f	0
164	Ginger Snap Patisserie	\N	Bakery & Café	Orchard Park	Orchard Park, NY 14127	\N	\N	\N	$	60	t	2026-04-02 19:15:00.316845	f	0
165	Green Eats	\N	Healthy	Orchard Park	Orchard Park, NY 14127	\N	\N	\N	$$	60	t	2026-04-02 19:15:04.252586	f	0
166	Harvest Hill Golf	\N	Bar & Grill	Orchard Park	Orchard Park, NY 14127	\N	\N	\N	$$	60	t	2026-04-02 19:15:08.164089	f	0
167	Kaylena Marie Bakery	\N	Bakery	Orchard Park	Orchard Park, NY 14127	\N	\N	\N	$	60	t	2026-04-02 19:15:11.956785	f	0
168	Kettles	\N	American	Orchard Park	Orchard Park, NY 14127	\N	\N	\N	$$	60	t	2026-04-02 19:15:16.391803	f	0
169	Louie's Texas Hots OP	\N	Hot Dogs	Orchard Park	Orchard Park, NY 14127	\N	\N	\N	$	60	t	2026-04-02 19:15:20.328764	f	0
171	Mansard Eatery	\N	American	Orchard Park	Orchard Park, NY 14127	\N	\N	\N	$$	60	t	2026-04-02 19:15:28.912736	f	0
172	Mario's Bistro & Brews	\N	American	Orchard Park	Orchard Park, NY 14127	\N	\N	\N	$$	60	t	2026-04-02 19:15:32.705026	f	0
173	NYBP Beer Lodge	\N	Bar & Grill	Orchard Park	Orchard Park, NY 14127	\N	\N	\N	$$	60	t	2026-04-02 19:15:36.624875	f	0
174	Off The Wall Sandwich	\N	Sandwiches	Orchard Park	Orchard Park, NY 14127	\N	\N	\N	$	60	t	2026-04-02 19:15:40.668078	f	0
175	Oneill's OP	\N	Irish Pub	Orchard Park	Orchard Park, NY 14127	\N	\N	\N	$$	60	t	2026-04-02 19:15:44.527743	f	0
176	OP Social & Tap	\N	Bar & Grill	Orchard Park	Orchard Park, NY 14127	\N	\N	\N	$$	60	t	2026-04-02 19:15:48.447963	f	0
177	Spot OP	\N	Café	Orchard Park	Orchard Park, NY 14127	\N	\N	\N	$	60	t	2026-04-02 19:15:52.509286	f	0
178	Strikers Lanes	\N	American	Orchard Park	Orchard Park, NY 14127	\N	\N	\N	$	60	t	2026-04-02 19:15:56.276068	f	0
179	T Squared Tees & Taps	\N	Bar & Grill	Orchard Park	Orchard Park, NY 14127	\N	\N	\N	$$	60	t	2026-04-02 19:16:00.457287	f	0
180	Taffy's Red Hots	\N	Hot Dogs	Orchard Park	Orchard Park, NY 14127	\N	\N	\N	$	60	t	2026-04-02 19:16:04.476527	f	0
181	Teds Hot Dogs	\N	Hot Dogs	Orchard Park	Orchard Park, NY 14127	\N	\N	\N	$	60	t	2026-04-02 19:16:08.400711	f	0
182	The Byrd House	\N	American	Orchard Park	Orchard Park, NY 14127	\N	\N	\N	$$	60	t	2026-04-02 19:16:12.24467	f	0
183	The Dove	\N	American	Orchard Park	Orchard Park, NY 14127	\N	\N	\N	$$	60	t	2026-04-02 19:16:16.098717	f	0
184	The Grange Outpost	\N	American	Orchard Park	Orchard Park, NY 14127	\N	\N	\N	$$	60	t	2026-04-02 19:16:20.134111	f	0
185	The Poked Yolk	\N	Breakfast	Orchard Park	Orchard Park, NY 14127	\N	\N	\N	$	60	t	2026-04-02 19:16:24.24394	f	0
186	The Wings Meeting PL	\N	Wings	Orchard Park	Orchard Park, NY 14127	\N	\N	\N	$	60	t	2026-04-02 19:16:28.244946	f	0
187	Wayland Brewing	\N	Brewery	Orchard Park	Orchard Park, NY 14127	\N	\N	\N	$$	60	t	2026-04-02 19:16:32.225259	f	0
188	Yianni's Corner Cafe	\N	Greek	Orchard Park	Orchard Park, NY 14127	\N	\N	\N	$$	60	t	2026-04-02 19:16:36.282724	f	0
154	240 South		American	Orchard Park	240 S Buffalo St, Orchard Park, NY 14127	\N	\N	https://static.spotapps.co/web/240south--com/custom/logo.png	$$	60	t	2026-04-02 19:14:20.574674	t	0
170	Mangia Ristorante & Cafe		Italian	Orchard Park	Orchard Park, NY 14127	\N	\N	https://mangiaristorante.com/wp-content/uploads/2025/08/ShrimpAndPasta.jpg	$$	60	t	2026-04-02 19:15:24.485118	f	0
\.


--
-- Data for Name: schedules; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.schedules (id, restaurant_id, day_of_week, open_time, close_time, is_open, slot_duration_minutes) FROM stdin;
1107	154	0	10:00	23:00	t	30
1109	154	2	11:00	22:00	t	30
1111	154	4	11:00	22:00	t	30
1113	154	6	10:00	23:00	t	30
1115	155	1	11:00	22:00	t	30
1117	155	3	11:00	22:00	t	30
1119	155	5	11:00	23:00	t	30
1121	156	0	10:00	23:00	t	30
1123	156	2	11:00	22:00	t	30
1125	156	4	11:00	22:00	t	30
1127	156	6	10:00	23:00	t	30
1129	157	1	11:00	22:00	t	30
1131	157	3	11:00	22:00	t	30
1133	157	5	11:00	23:00	t	30
1135	158	0	10:00	23:00	t	30
1137	158	2	11:00	22:00	t	30
1139	158	4	11:00	22:00	t	30
1141	158	6	10:00	23:00	t	30
1143	159	1	11:00	22:00	t	30
1145	159	3	11:00	22:00	t	30
1147	159	5	11:00	23:00	t	30
1149	160	0	10:00	23:00	t	30
1151	160	2	11:00	22:00	t	30
1153	160	4	11:00	22:00	t	30
1155	160	6	10:00	23:00	t	30
1157	161	1	11:00	22:00	t	30
1159	161	3	11:00	22:00	t	30
1161	161	5	11:00	23:00	t	30
1163	162	0	10:00	23:00	t	30
1165	162	2	11:00	22:00	t	30
1167	162	4	11:00	22:00	t	30
1169	162	6	10:00	23:00	t	30
1171	163	1	11:00	22:00	t	30
1173	163	3	11:00	22:00	t	30
1175	163	5	11:00	23:00	t	30
36	1	0	11:00	22:00	t	30
37	1	1	17:00	22:00	f	30
38	1	2	17:00	22:00	t	30
39	1	3	17:00	22:00	t	30
40	1	4	17:00	22:00	t	30
41	1	5	17:00	22:00	t	30
42	1	6	11:00	22:00	t	30
43	2	0	11:00	22:00	t	30
44	2	1	17:00	22:00	f	30
45	2	2	17:00	22:00	t	30
46	2	3	17:00	22:00	t	30
47	2	4	17:00	22:00	t	30
48	2	5	17:00	22:00	t	30
49	2	6	11:00	22:00	t	30
50	3	0	11:00	22:00	t	30
51	3	1	17:00	22:00	f	30
52	3	2	17:00	22:00	t	30
53	3	3	17:00	22:00	t	30
54	3	4	17:00	22:00	t	30
55	3	5	17:00	22:00	t	30
56	3	6	11:00	22:00	t	30
57	4	0	11:00	22:00	t	30
58	4	1	17:00	22:00	f	30
59	4	2	17:00	22:00	t	30
60	4	3	17:00	22:00	t	30
61	4	4	17:00	22:00	t	30
62	4	5	17:00	22:00	t	30
63	4	6	11:00	22:00	t	30
64	5	0	11:00	22:00	t	30
65	5	1	17:00	22:00	f	30
66	5	2	17:00	22:00	t	30
67	5	3	17:00	22:00	t	30
68	5	4	17:00	22:00	t	30
69	5	5	17:00	22:00	t	30
70	5	6	11:00	22:00	t	30
71	6	0	11:00	22:00	t	30
72	6	1	17:00	22:00	f	30
73	6	2	17:00	22:00	t	30
74	6	3	17:00	22:00	t	30
75	6	4	17:00	22:00	t	30
76	6	5	17:00	22:00	t	30
77	6	6	11:00	22:00	t	30
78	7	0	11:00	22:00	t	30
79	7	1	17:00	22:00	f	30
80	7	2	17:00	22:00	t	30
81	7	3	17:00	22:00	t	30
82	7	4	17:00	22:00	t	30
83	7	5	17:00	22:00	t	30
84	7	6	11:00	22:00	t	30
85	8	0	11:00	22:00	t	30
86	8	1	17:00	22:00	f	30
87	8	2	17:00	22:00	t	30
88	8	3	17:00	22:00	t	30
89	8	4	17:00	22:00	t	30
90	8	5	17:00	22:00	t	30
91	8	6	11:00	22:00	t	30
92	9	0	11:00	22:00	t	30
93	9	1	17:00	22:00	f	30
94	9	2	17:00	22:00	t	30
95	9	3	17:00	22:00	t	30
96	9	4	17:00	22:00	t	30
97	9	5	17:00	22:00	t	30
98	9	6	11:00	22:00	t	30
99	10	0	11:00	22:00	t	30
100	10	1	17:00	22:00	f	30
101	10	2	17:00	22:00	t	30
102	10	3	17:00	22:00	t	30
103	10	4	17:00	22:00	t	30
104	10	5	17:00	22:00	t	30
105	10	6	11:00	22:00	t	30
106	11	0	11:00	22:00	t	30
107	11	1	17:00	22:00	f	30
108	11	2	17:00	22:00	t	30
109	11	3	17:00	22:00	t	30
110	11	4	17:00	22:00	t	30
111	11	5	17:00	22:00	t	30
112	11	6	11:00	22:00	t	30
113	12	0	11:00	22:00	t	30
114	12	1	17:00	22:00	f	30
115	12	2	17:00	22:00	t	30
116	12	3	17:00	22:00	t	30
117	12	4	17:00	22:00	t	30
118	12	5	17:00	22:00	t	30
119	12	6	11:00	22:00	t	30
120	13	0	11:00	22:00	t	30
121	13	1	17:00	22:00	f	30
122	13	2	17:00	22:00	t	30
123	13	3	17:00	22:00	t	30
124	13	4	17:00	22:00	t	30
125	13	5	17:00	22:00	t	30
126	13	6	11:00	22:00	t	30
127	14	0	11:00	22:00	t	30
128	14	1	17:00	22:00	f	30
129	14	2	17:00	22:00	t	30
130	14	3	17:00	22:00	t	30
131	14	4	17:00	22:00	t	30
132	14	5	17:00	22:00	t	30
133	14	6	11:00	22:00	t	30
134	15	0	11:00	22:00	t	30
135	15	1	17:00	22:00	f	30
136	15	2	17:00	22:00	t	30
137	15	3	17:00	22:00	t	30
138	15	4	17:00	22:00	t	30
139	15	5	17:00	22:00	t	30
140	15	6	11:00	22:00	t	30
141	16	0	11:00	22:00	t	30
142	16	1	17:00	22:00	f	30
143	16	2	17:00	22:00	t	30
144	16	3	17:00	22:00	t	30
145	16	4	17:00	22:00	t	30
146	16	5	17:00	22:00	t	30
147	16	6	11:00	22:00	t	30
148	17	0	11:00	22:00	t	30
149	17	1	17:00	22:00	f	30
150	17	2	17:00	22:00	t	30
151	17	3	17:00	22:00	t	30
152	17	4	17:00	22:00	t	30
153	17	5	17:00	22:00	t	30
154	17	6	11:00	22:00	t	30
155	18	0	11:00	22:00	t	30
156	18	1	17:00	22:00	f	30
157	18	2	17:00	22:00	t	30
158	18	3	17:00	22:00	t	30
159	18	4	17:00	22:00	t	30
160	18	5	17:00	22:00	t	30
161	18	6	11:00	22:00	t	30
162	19	0	11:00	22:00	t	30
163	19	1	17:00	22:00	f	30
164	19	2	17:00	22:00	t	30
165	19	3	17:00	22:00	t	30
166	19	4	17:00	22:00	t	30
167	19	5	17:00	22:00	t	30
168	19	6	11:00	22:00	t	30
169	20	0	11:00	22:00	t	30
170	20	1	17:00	22:00	f	30
171	20	2	17:00	22:00	t	30
172	20	3	17:00	22:00	t	30
173	20	4	17:00	22:00	t	30
174	20	5	17:00	22:00	t	30
175	20	6	11:00	22:00	t	30
176	21	0	11:00	22:00	t	30
177	21	1	17:00	22:00	f	30
178	21	2	17:00	22:00	t	30
179	21	3	17:00	22:00	t	30
180	21	4	17:00	22:00	t	30
181	21	5	17:00	22:00	t	30
182	21	6	11:00	22:00	t	30
183	22	0	11:00	22:00	t	30
184	22	1	17:00	22:00	f	30
185	22	2	17:00	22:00	t	30
186	22	3	17:00	22:00	t	30
187	22	4	17:00	22:00	t	30
188	22	5	17:00	22:00	t	30
189	22	6	11:00	22:00	t	30
190	23	0	11:00	22:00	t	30
191	23	1	17:00	22:00	f	30
192	23	2	17:00	22:00	t	30
193	23	3	17:00	22:00	t	30
194	23	4	17:00	22:00	t	30
195	23	5	17:00	22:00	t	30
196	23	6	11:00	22:00	t	30
197	24	0	11:00	22:00	t	30
198	24	1	17:00	22:00	f	30
199	24	2	17:00	22:00	t	30
200	24	3	17:00	22:00	t	30
201	24	4	17:00	22:00	t	30
202	24	5	17:00	22:00	t	30
203	24	6	11:00	22:00	t	30
204	25	0	11:00	22:00	t	30
205	25	1	17:00	22:00	f	30
206	25	2	17:00	22:00	t	30
207	25	3	17:00	22:00	t	30
208	25	4	17:00	22:00	t	30
209	25	5	17:00	22:00	t	30
210	25	6	11:00	22:00	t	30
211	26	0	11:00	22:00	t	30
212	26	1	17:00	22:00	f	30
213	26	2	17:00	22:00	t	30
214	26	3	17:00	22:00	t	30
215	26	4	17:00	22:00	t	30
216	26	5	17:00	22:00	t	30
217	26	6	11:00	22:00	t	30
218	27	0	11:00	22:00	t	30
219	27	1	17:00	22:00	f	30
220	27	2	17:00	22:00	t	30
221	27	3	17:00	22:00	t	30
222	27	4	17:00	22:00	t	30
223	27	5	17:00	22:00	t	30
224	27	6	11:00	22:00	t	30
225	28	0	11:00	22:00	t	30
226	28	1	17:00	22:00	f	30
227	28	2	17:00	22:00	t	30
228	28	3	17:00	22:00	t	30
229	28	4	17:00	22:00	t	30
230	28	5	17:00	22:00	t	30
231	28	6	11:00	22:00	t	30
232	29	0	11:00	22:00	t	30
233	29	1	17:00	22:00	f	30
234	29	2	17:00	22:00	t	30
235	29	3	17:00	22:00	t	30
236	29	4	17:00	22:00	t	30
237	29	5	17:00	22:00	t	30
238	29	6	11:00	22:00	t	30
239	30	0	11:00	22:00	t	30
240	30	1	17:00	22:00	f	30
241	30	2	17:00	22:00	t	30
242	30	3	17:00	22:00	t	30
243	30	4	17:00	22:00	t	30
244	30	5	17:00	22:00	t	30
245	30	6	11:00	22:00	t	30
246	31	0	11:00	22:00	t	30
247	31	1	17:00	22:00	f	30
248	31	2	17:00	22:00	t	30
249	31	3	17:00	22:00	t	30
250	31	4	17:00	22:00	t	30
251	31	5	17:00	22:00	t	30
252	31	6	11:00	22:00	t	30
253	32	0	11:00	22:00	t	30
254	32	1	17:00	22:00	f	30
255	32	2	17:00	22:00	t	30
256	32	3	17:00	22:00	t	30
257	32	4	17:00	22:00	t	30
258	32	5	17:00	22:00	t	30
259	32	6	11:00	22:00	t	30
260	33	0	11:00	22:00	t	30
261	33	1	17:00	22:00	f	30
262	33	2	17:00	22:00	t	30
263	33	3	17:00	22:00	t	30
264	33	4	17:00	22:00	t	30
265	33	5	17:00	22:00	t	30
266	33	6	11:00	22:00	t	30
267	34	0	11:00	22:00	t	30
268	34	1	17:00	22:00	f	30
269	34	2	17:00	22:00	t	30
270	34	3	17:00	22:00	t	30
271	34	4	17:00	22:00	t	30
272	34	5	17:00	22:00	t	30
273	34	6	11:00	22:00	t	30
274	35	0	11:00	22:00	t	30
275	35	1	17:00	22:00	f	30
276	35	2	17:00	22:00	t	30
277	35	3	17:00	22:00	t	30
278	35	4	17:00	22:00	t	30
279	35	5	17:00	22:00	t	30
280	35	6	11:00	22:00	t	30
281	36	0	11:00	22:00	t	30
282	36	1	17:00	22:00	f	30
283	36	2	17:00	22:00	t	30
284	36	3	17:00	22:00	t	30
285	36	4	17:00	22:00	t	30
286	36	5	17:00	22:00	t	30
287	36	6	11:00	22:00	t	30
288	37	0	11:00	22:00	t	30
289	37	1	17:00	22:00	f	30
290	37	2	17:00	22:00	t	30
291	37	3	17:00	22:00	t	30
292	37	4	17:00	22:00	t	30
293	37	5	17:00	22:00	t	30
294	37	6	11:00	22:00	t	30
295	38	0	11:00	22:00	t	30
296	38	1	17:00	22:00	f	30
297	38	2	17:00	22:00	t	30
298	38	3	17:00	22:00	t	30
299	38	4	17:00	22:00	t	30
300	38	5	17:00	22:00	t	30
301	38	6	11:00	22:00	t	30
302	39	0	11:00	22:00	t	30
303	39	1	17:00	22:00	f	30
304	39	2	17:00	22:00	t	30
305	39	3	17:00	22:00	t	30
306	39	4	17:00	22:00	t	30
307	39	5	17:00	22:00	t	30
308	39	6	11:00	22:00	t	30
309	40	0	11:00	22:00	t	30
310	40	1	17:00	22:00	f	30
311	40	2	17:00	22:00	t	30
312	40	3	17:00	22:00	t	30
313	40	4	17:00	22:00	t	30
314	40	5	17:00	22:00	t	30
315	40	6	11:00	22:00	t	30
316	41	0	11:00	22:00	t	30
317	41	1	17:00	22:00	f	30
318	41	2	17:00	22:00	t	30
319	41	3	17:00	22:00	t	30
320	41	4	17:00	22:00	t	30
321	41	5	17:00	22:00	t	30
322	41	6	11:00	22:00	t	30
323	42	0	11:00	22:00	t	30
324	42	1	17:00	22:00	f	30
325	42	2	17:00	22:00	t	30
326	42	3	17:00	22:00	t	30
327	42	4	17:00	22:00	t	30
328	42	5	17:00	22:00	t	30
329	42	6	11:00	22:00	t	30
330	43	0	11:00	22:00	t	30
331	43	1	17:00	22:00	f	30
332	43	2	17:00	22:00	t	30
333	43	3	17:00	22:00	t	30
334	43	4	17:00	22:00	t	30
335	43	5	17:00	22:00	t	30
336	43	6	11:00	22:00	t	30
337	44	0	11:00	22:00	t	30
338	44	1	17:00	22:00	f	30
339	44	2	17:00	22:00	t	30
340	44	3	17:00	22:00	t	30
341	44	4	17:00	22:00	t	30
342	44	5	17:00	22:00	t	30
343	44	6	11:00	22:00	t	30
344	45	0	11:00	22:00	t	30
345	45	1	17:00	22:00	f	30
346	45	2	17:00	22:00	t	30
347	45	3	17:00	22:00	t	30
348	45	4	17:00	22:00	t	30
349	45	5	17:00	22:00	t	30
350	45	6	11:00	22:00	t	30
351	46	0	11:00	22:00	t	30
352	46	1	17:00	22:00	f	30
353	46	2	17:00	22:00	t	30
354	46	3	17:00	22:00	t	30
355	46	4	17:00	22:00	t	30
356	46	5	17:00	22:00	t	30
357	46	6	11:00	22:00	t	30
358	47	0	11:00	22:00	t	30
359	47	1	17:00	22:00	f	30
360	47	2	17:00	22:00	t	30
361	47	3	17:00	22:00	t	30
362	47	4	17:00	22:00	t	30
363	47	5	17:00	22:00	t	30
364	47	6	11:00	22:00	t	30
365	48	0	11:00	22:00	t	30
366	48	1	17:00	22:00	f	30
367	48	2	17:00	22:00	t	30
368	48	3	17:00	22:00	t	30
369	48	4	17:00	22:00	t	30
370	48	5	17:00	22:00	t	30
371	48	6	11:00	22:00	t	30
372	49	0	11:00	22:00	t	30
373	49	1	17:00	22:00	f	30
374	49	2	17:00	22:00	t	30
375	49	3	17:00	22:00	t	30
376	49	4	17:00	22:00	t	30
377	49	5	17:00	22:00	t	30
378	49	6	11:00	22:00	t	30
379	50	0	11:00	22:00	t	30
380	50	1	17:00	22:00	f	30
381	50	2	17:00	22:00	t	30
382	50	3	17:00	22:00	t	30
383	50	4	17:00	22:00	t	30
384	50	5	17:00	22:00	t	30
385	50	6	11:00	22:00	t	30
386	51	0	11:00	22:00	t	30
387	51	1	17:00	22:00	f	30
388	51	2	17:00	22:00	t	30
389	51	3	17:00	22:00	t	30
390	51	4	17:00	22:00	t	30
391	51	5	17:00	22:00	t	30
392	51	6	11:00	22:00	t	30
393	52	0	11:00	22:00	t	30
394	52	1	17:00	22:00	f	30
395	52	2	17:00	22:00	t	30
396	52	3	17:00	22:00	t	30
397	52	4	17:00	22:00	t	30
398	52	5	17:00	22:00	t	30
399	52	6	11:00	22:00	t	30
400	53	0	11:00	22:00	t	30
401	53	1	17:00	22:00	f	30
402	53	2	17:00	22:00	t	30
403	53	3	17:00	22:00	t	30
404	53	4	17:00	22:00	t	30
405	53	5	17:00	22:00	t	30
406	53	6	11:00	22:00	t	30
407	54	0	11:00	22:00	t	30
408	54	1	17:00	22:00	f	30
409	54	2	17:00	22:00	t	30
410	54	3	17:00	22:00	t	30
411	54	4	17:00	22:00	t	30
412	54	5	17:00	22:00	t	30
413	54	6	11:00	22:00	t	30
414	55	0	11:00	22:00	t	30
415	55	1	17:00	22:00	f	30
416	55	2	17:00	22:00	t	30
417	55	3	17:00	22:00	t	30
418	55	4	17:00	22:00	t	30
419	55	5	17:00	22:00	t	30
420	55	6	11:00	22:00	t	30
421	56	0	11:00	22:00	t	30
422	56	1	17:00	22:00	f	30
423	56	2	17:00	22:00	t	30
424	56	3	17:00	22:00	t	30
425	56	4	17:00	22:00	t	30
426	56	5	17:00	22:00	t	30
427	56	6	11:00	22:00	t	30
428	57	0	11:00	22:00	t	30
429	57	1	17:00	22:00	f	30
430	57	2	17:00	22:00	t	30
431	57	3	17:00	22:00	t	30
432	57	4	17:00	22:00	t	30
433	57	5	17:00	22:00	t	30
434	57	6	11:00	22:00	t	30
435	58	0	11:00	22:00	t	30
436	58	1	17:00	22:00	f	30
437	58	2	17:00	22:00	t	30
438	58	3	17:00	22:00	t	30
439	58	4	17:00	22:00	t	30
440	58	5	17:00	22:00	t	30
441	58	6	11:00	22:00	t	30
442	59	0	11:00	22:00	t	30
443	59	1	17:00	22:00	f	30
444	59	2	17:00	22:00	t	30
445	59	3	17:00	22:00	t	30
446	59	4	17:00	22:00	t	30
447	59	5	17:00	22:00	t	30
448	59	6	11:00	22:00	t	30
449	60	0	11:00	22:00	t	30
450	60	1	17:00	22:00	f	30
451	60	2	17:00	22:00	t	30
452	60	3	17:00	22:00	t	30
453	60	4	17:00	22:00	t	30
454	60	5	17:00	22:00	t	30
455	60	6	11:00	22:00	t	30
456	61	0	11:00	22:00	t	30
457	61	1	17:00	22:00	f	30
458	61	2	17:00	22:00	t	30
459	61	3	17:00	22:00	t	30
460	61	4	17:00	22:00	t	30
461	61	5	17:00	22:00	t	30
462	61	6	11:00	22:00	t	30
463	62	0	11:00	22:00	t	30
464	62	1	17:00	22:00	f	30
465	62	2	17:00	22:00	t	30
466	62	3	17:00	22:00	t	30
467	62	4	17:00	22:00	t	30
468	62	5	17:00	22:00	t	30
469	62	6	11:00	22:00	t	30
470	63	0	11:00	22:00	t	30
471	63	1	17:00	22:00	f	30
472	63	2	17:00	22:00	t	30
473	63	3	17:00	22:00	t	30
474	63	4	17:00	22:00	t	30
475	63	5	17:00	22:00	t	30
476	63	6	11:00	22:00	t	30
477	64	0	11:00	22:00	t	30
478	64	1	17:00	22:00	f	30
479	64	2	17:00	22:00	t	30
480	64	3	17:00	22:00	t	30
481	64	4	17:00	22:00	t	30
482	64	5	17:00	22:00	t	30
483	64	6	11:00	22:00	t	30
484	65	0	11:00	22:00	t	30
485	65	1	17:00	22:00	f	30
486	65	2	17:00	22:00	t	30
487	65	3	17:00	22:00	t	30
488	65	4	17:00	22:00	t	30
489	65	5	17:00	22:00	t	30
490	65	6	11:00	22:00	t	30
491	66	0	11:00	22:00	t	30
492	66	1	17:00	22:00	f	30
493	66	2	17:00	22:00	t	30
494	66	3	17:00	22:00	t	30
495	66	4	17:00	22:00	t	30
496	66	5	17:00	22:00	t	30
497	66	6	11:00	22:00	t	30
498	67	0	11:00	22:00	t	30
499	67	1	17:00	22:00	f	30
500	67	2	17:00	22:00	t	30
501	67	3	17:00	22:00	t	30
502	67	4	17:00	22:00	t	30
503	67	5	17:00	22:00	t	30
504	67	6	11:00	22:00	t	30
505	68	0	11:00	22:00	t	30
506	68	1	17:00	22:00	f	30
507	68	2	17:00	22:00	t	30
508	68	3	17:00	22:00	t	30
509	68	4	17:00	22:00	t	30
510	68	5	17:00	22:00	t	30
511	68	6	11:00	22:00	t	30
512	69	0	11:00	22:00	t	30
513	69	1	17:00	22:00	f	30
514	69	2	17:00	22:00	t	30
515	69	3	17:00	22:00	t	30
516	69	4	17:00	22:00	t	30
517	69	5	17:00	22:00	t	30
518	69	6	11:00	22:00	t	30
519	70	0	11:00	22:00	t	30
520	70	1	17:00	22:00	f	30
521	70	2	17:00	22:00	t	30
522	70	3	17:00	22:00	t	30
523	70	4	17:00	22:00	t	30
524	70	5	17:00	22:00	t	30
525	70	6	11:00	22:00	t	30
526	71	0	11:00	22:00	t	30
527	71	1	17:00	22:00	f	30
528	71	2	17:00	22:00	t	30
529	71	3	17:00	22:00	t	30
530	71	4	17:00	22:00	t	30
531	71	5	17:00	22:00	t	30
532	71	6	11:00	22:00	t	30
533	72	0	11:00	22:00	t	30
534	72	1	17:00	22:00	f	30
535	72	2	17:00	22:00	t	30
536	72	3	17:00	22:00	t	30
537	72	4	17:00	22:00	t	30
538	72	5	17:00	22:00	t	30
539	72	6	11:00	22:00	t	30
540	73	0	11:00	22:00	t	30
541	73	1	17:00	22:00	f	30
542	73	2	17:00	22:00	t	30
543	73	3	17:00	22:00	t	30
544	73	4	17:00	22:00	t	30
545	73	5	17:00	22:00	t	30
546	73	6	11:00	22:00	t	30
547	74	0	11:00	22:00	t	30
548	74	1	17:00	22:00	f	30
549	74	2	17:00	22:00	t	30
550	74	3	17:00	22:00	t	30
551	74	4	17:00	22:00	t	30
552	74	5	17:00	22:00	t	30
553	74	6	11:00	22:00	t	30
554	75	0	11:00	22:00	t	30
555	75	1	17:00	22:00	f	30
556	75	2	17:00	22:00	t	30
557	75	3	17:00	22:00	t	30
558	75	4	17:00	22:00	t	30
559	75	5	17:00	22:00	t	30
560	75	6	11:00	22:00	t	30
561	76	0	11:00	22:00	t	30
562	76	1	17:00	22:00	f	30
563	76	2	17:00	22:00	t	30
564	76	3	17:00	22:00	t	30
565	76	4	17:00	22:00	t	30
566	76	5	17:00	22:00	t	30
567	76	6	11:00	22:00	t	30
568	77	0	11:00	22:00	t	30
569	77	1	17:00	22:00	f	30
570	77	2	17:00	22:00	t	30
571	77	3	17:00	22:00	t	30
572	77	4	17:00	22:00	t	30
573	77	5	17:00	22:00	t	30
574	77	6	11:00	22:00	t	30
575	78	0	11:00	22:00	t	30
576	78	1	17:00	22:00	f	30
577	78	2	17:00	22:00	t	30
578	78	3	17:00	22:00	t	30
579	78	4	17:00	22:00	t	30
580	78	5	17:00	22:00	t	30
581	78	6	11:00	22:00	t	30
582	79	0	11:00	22:00	t	30
583	79	1	17:00	22:00	f	30
584	79	2	17:00	22:00	t	30
585	79	3	17:00	22:00	t	30
586	79	4	17:00	22:00	t	30
587	79	5	17:00	22:00	t	30
588	79	6	11:00	22:00	t	30
589	80	0	11:00	22:00	t	30
590	80	1	17:00	22:00	f	30
591	80	2	17:00	22:00	t	30
592	80	3	17:00	22:00	t	30
593	80	4	17:00	22:00	t	30
594	80	5	17:00	22:00	t	30
595	80	6	11:00	22:00	t	30
596	81	0	11:00	22:00	t	30
597	81	1	17:00	22:00	f	30
598	81	2	17:00	22:00	t	30
599	81	3	17:00	22:00	t	30
600	81	4	17:00	22:00	t	30
601	81	5	17:00	22:00	t	30
602	81	6	11:00	22:00	t	30
603	82	0	11:00	22:00	t	30
604	82	1	17:00	22:00	f	30
605	82	2	17:00	22:00	t	30
606	82	3	17:00	22:00	t	30
607	82	4	17:00	22:00	t	30
608	82	5	17:00	22:00	t	30
609	82	6	11:00	22:00	t	30
610	83	0	11:00	22:00	t	30
611	83	1	17:00	22:00	f	30
612	83	2	17:00	22:00	t	30
613	83	3	17:00	22:00	t	30
614	83	4	17:00	22:00	t	30
615	83	5	17:00	22:00	t	30
616	83	6	11:00	22:00	t	30
617	84	0	11:00	22:00	t	30
618	84	1	17:00	22:00	f	30
619	84	2	17:00	22:00	t	30
620	84	3	17:00	22:00	t	30
621	84	4	17:00	22:00	t	30
622	84	5	17:00	22:00	t	30
623	84	6	11:00	22:00	t	30
624	85	0	11:00	22:00	t	30
625	85	1	17:00	22:00	f	30
626	85	2	17:00	22:00	t	30
627	85	3	17:00	22:00	t	30
628	85	4	17:00	22:00	t	30
629	85	5	17:00	22:00	t	30
630	85	6	11:00	22:00	t	30
631	86	0	11:00	22:00	t	30
632	86	1	17:00	22:00	f	30
633	86	2	17:00	22:00	t	30
634	86	3	17:00	22:00	t	30
635	86	4	17:00	22:00	t	30
636	86	5	17:00	22:00	t	30
637	86	6	11:00	22:00	t	30
638	87	0	11:00	22:00	t	30
639	87	1	17:00	22:00	f	30
640	87	2	17:00	22:00	t	30
641	87	3	17:00	22:00	t	30
642	87	4	17:00	22:00	t	30
643	87	5	17:00	22:00	t	30
644	87	6	11:00	22:00	t	30
645	88	0	11:00	22:00	t	30
646	88	1	17:00	22:00	f	30
647	88	2	17:00	22:00	t	30
648	88	3	17:00	22:00	t	30
649	88	4	17:00	22:00	t	30
650	88	5	17:00	22:00	t	30
651	88	6	11:00	22:00	t	30
652	89	0	11:00	22:00	t	30
653	89	1	17:00	22:00	f	30
654	89	2	17:00	22:00	t	30
655	89	3	17:00	22:00	t	30
656	89	4	17:00	22:00	t	30
657	89	5	17:00	22:00	t	30
658	89	6	11:00	22:00	t	30
659	90	0	11:00	22:00	t	30
660	90	1	17:00	22:00	f	30
661	90	2	17:00	22:00	t	30
662	90	3	17:00	22:00	t	30
663	90	4	17:00	22:00	t	30
664	90	5	17:00	22:00	t	30
665	90	6	11:00	22:00	t	30
666	91	0	11:00	22:00	t	30
667	91	1	17:00	22:00	f	30
668	91	2	17:00	22:00	t	30
669	91	3	17:00	22:00	t	30
670	91	4	17:00	22:00	t	30
671	91	5	17:00	22:00	t	30
672	91	6	11:00	22:00	t	30
673	92	0	11:00	22:00	t	30
674	92	1	17:00	22:00	f	30
675	92	2	17:00	22:00	t	30
676	92	3	17:00	22:00	t	30
677	92	4	17:00	22:00	t	30
678	92	5	17:00	22:00	t	30
679	92	6	11:00	22:00	t	30
680	93	0	11:00	22:00	t	30
681	93	1	17:00	22:00	f	30
682	93	2	17:00	22:00	t	30
683	93	3	17:00	22:00	t	30
684	93	4	17:00	22:00	t	30
685	93	5	17:00	22:00	t	30
686	93	6	11:00	22:00	t	30
687	94	0	11:00	22:00	t	30
688	94	1	17:00	22:00	f	30
689	94	2	17:00	22:00	t	30
690	94	3	17:00	22:00	t	30
691	94	4	17:00	22:00	t	30
692	94	5	17:00	22:00	t	30
693	94	6	11:00	22:00	t	30
694	95	0	11:00	22:00	t	30
695	95	1	17:00	22:00	f	30
696	95	2	17:00	22:00	t	30
697	95	3	17:00	22:00	t	30
698	95	4	17:00	22:00	t	30
699	95	5	17:00	22:00	t	30
700	95	6	11:00	22:00	t	30
701	96	0	11:00	22:00	t	30
702	96	1	17:00	22:00	f	30
703	96	2	17:00	22:00	t	30
704	96	3	17:00	22:00	t	30
705	96	4	17:00	22:00	t	30
706	96	5	17:00	22:00	t	30
707	96	6	11:00	22:00	t	30
708	97	0	11:00	22:00	t	30
709	97	1	17:00	22:00	f	30
710	97	2	17:00	22:00	t	30
711	97	3	17:00	22:00	t	30
712	97	4	17:00	22:00	t	30
713	97	5	17:00	22:00	t	30
714	97	6	11:00	22:00	t	30
715	98	0	11:00	22:00	t	30
716	98	1	17:00	22:00	f	30
717	98	2	17:00	22:00	t	30
718	98	3	17:00	22:00	t	30
719	98	4	17:00	22:00	t	30
720	98	5	17:00	22:00	t	30
721	98	6	11:00	22:00	t	30
722	99	0	11:00	22:00	t	30
723	99	1	17:00	22:00	f	30
724	99	2	17:00	22:00	t	30
725	99	3	17:00	22:00	t	30
726	99	4	17:00	22:00	t	30
727	99	5	17:00	22:00	t	30
728	99	6	11:00	22:00	t	30
729	100	0	11:00	22:00	t	30
730	100	1	17:00	22:00	f	30
731	100	2	17:00	22:00	t	30
732	100	3	17:00	22:00	t	30
733	100	4	17:00	22:00	t	30
734	100	5	17:00	22:00	t	30
735	100	6	11:00	22:00	t	30
736	101	0	11:00	22:00	t	30
737	101	1	17:00	22:00	f	30
738	101	2	17:00	22:00	t	30
739	101	3	17:00	22:00	t	30
740	101	4	17:00	22:00	t	30
741	101	5	17:00	22:00	t	30
742	101	6	11:00	22:00	t	30
743	102	0	11:00	22:00	t	30
744	102	1	17:00	22:00	f	30
745	102	2	17:00	22:00	t	30
746	102	3	17:00	22:00	t	30
747	102	4	17:00	22:00	t	30
748	102	5	17:00	22:00	t	30
749	102	6	11:00	22:00	t	30
750	103	0	11:00	22:00	t	30
751	103	1	17:00	22:00	f	30
752	103	2	17:00	22:00	t	30
753	103	3	17:00	22:00	t	30
754	103	4	17:00	22:00	t	30
755	103	5	17:00	22:00	t	30
756	103	6	11:00	22:00	t	30
757	104	0	11:00	22:00	t	30
758	104	1	17:00	22:00	f	30
759	104	2	17:00	22:00	t	30
760	104	3	17:00	22:00	t	30
761	104	4	17:00	22:00	t	30
762	104	5	17:00	22:00	t	30
763	104	6	11:00	22:00	t	30
764	105	0	11:00	22:00	t	30
765	105	1	17:00	22:00	f	30
766	105	2	17:00	22:00	t	30
767	105	3	17:00	22:00	t	30
768	105	4	17:00	22:00	t	30
769	105	5	17:00	22:00	t	30
770	105	6	11:00	22:00	t	30
771	106	0	11:00	22:00	t	30
772	106	1	17:00	22:00	f	30
773	106	2	17:00	22:00	t	30
774	106	3	17:00	22:00	t	30
775	106	4	17:00	22:00	t	30
776	106	5	17:00	22:00	t	30
777	106	6	11:00	22:00	t	30
778	107	0	11:00	22:00	t	30
779	107	1	17:00	22:00	f	30
780	107	2	17:00	22:00	t	30
781	107	3	17:00	22:00	t	30
782	107	4	17:00	22:00	t	30
783	107	5	17:00	22:00	t	30
784	107	6	11:00	22:00	t	30
785	108	0	11:00	22:00	t	30
786	108	1	17:00	22:00	f	30
787	108	2	17:00	22:00	t	30
788	108	3	17:00	22:00	t	30
789	108	4	17:00	22:00	t	30
790	108	5	17:00	22:00	t	30
791	108	6	11:00	22:00	t	30
792	109	0	11:00	22:00	t	30
793	109	1	17:00	22:00	f	30
794	109	2	17:00	22:00	t	30
795	109	3	17:00	22:00	t	30
796	109	4	17:00	22:00	t	30
797	109	5	17:00	22:00	t	30
798	109	6	11:00	22:00	t	30
799	110	0	11:00	22:00	t	30
800	110	1	17:00	22:00	f	30
801	110	2	17:00	22:00	t	30
802	110	3	17:00	22:00	t	30
803	110	4	17:00	22:00	t	30
804	110	5	17:00	22:00	t	30
805	110	6	11:00	22:00	t	30
806	111	0	11:00	22:00	t	30
807	111	1	17:00	22:00	f	30
808	111	2	17:00	22:00	t	30
809	111	3	17:00	22:00	t	30
810	111	4	17:00	22:00	t	30
811	111	5	17:00	22:00	t	30
812	111	6	11:00	22:00	t	30
813	112	0	11:00	22:00	t	30
814	112	1	17:00	22:00	f	30
815	112	2	17:00	22:00	t	30
816	112	3	17:00	22:00	t	30
817	112	4	17:00	22:00	t	30
818	112	5	17:00	22:00	t	30
819	112	6	11:00	22:00	t	30
820	113	0	11:00	22:00	t	30
821	113	1	17:00	22:00	f	30
822	113	2	17:00	22:00	t	30
823	113	3	17:00	22:00	t	30
824	113	4	17:00	22:00	t	30
825	113	5	17:00	22:00	t	30
826	113	6	11:00	22:00	t	30
827	114	0	11:00	22:00	t	30
828	114	1	17:00	22:00	f	30
829	114	2	17:00	22:00	t	30
830	114	3	17:00	22:00	t	30
831	114	4	17:00	22:00	t	30
832	114	5	17:00	22:00	t	30
833	114	6	11:00	22:00	t	30
834	115	0	11:00	22:00	t	30
835	115	1	17:00	22:00	f	30
836	115	2	17:00	22:00	t	30
837	115	3	17:00	22:00	t	30
838	115	4	17:00	22:00	t	30
839	115	5	17:00	22:00	t	30
840	115	6	11:00	22:00	t	30
841	116	0	11:00	22:00	t	30
842	116	1	17:00	22:00	f	30
843	116	2	17:00	22:00	t	30
844	116	3	17:00	22:00	t	30
845	116	4	17:00	22:00	t	30
846	116	5	17:00	22:00	t	30
847	116	6	11:00	22:00	t	30
848	117	0	11:00	22:00	t	30
849	117	1	17:00	22:00	f	30
850	117	2	17:00	22:00	t	30
851	117	3	17:00	22:00	t	30
852	117	4	17:00	22:00	t	30
853	117	5	17:00	22:00	t	30
854	117	6	11:00	22:00	t	30
855	118	0	11:00	22:00	t	30
856	118	1	17:00	22:00	f	30
857	118	2	17:00	22:00	t	30
858	118	3	17:00	22:00	t	30
859	118	4	17:00	22:00	t	30
860	118	5	17:00	22:00	t	30
861	118	6	11:00	22:00	t	30
862	119	0	11:00	22:00	t	30
863	119	1	17:00	22:00	f	30
864	119	2	17:00	22:00	t	30
865	119	3	17:00	22:00	t	30
866	119	4	17:00	22:00	t	30
867	119	5	17:00	22:00	t	30
868	119	6	11:00	22:00	t	30
869	120	0	11:00	22:00	t	30
870	120	1	17:00	22:00	f	30
871	120	2	17:00	22:00	t	30
872	120	3	17:00	22:00	t	30
873	120	4	17:00	22:00	t	30
874	120	5	17:00	22:00	t	30
875	120	6	11:00	22:00	t	30
876	121	0	11:00	22:00	t	30
877	121	1	17:00	22:00	f	30
878	121	2	17:00	22:00	t	30
879	121	3	17:00	22:00	t	30
880	121	4	17:00	22:00	t	30
881	121	5	17:00	22:00	t	30
882	121	6	11:00	22:00	t	30
883	122	0	11:00	22:00	t	30
884	122	1	17:00	22:00	f	30
885	122	2	17:00	22:00	t	30
886	122	3	17:00	22:00	t	30
887	122	4	17:00	22:00	t	30
888	122	5	17:00	22:00	t	30
889	122	6	11:00	22:00	t	30
890	123	0	11:00	22:00	t	30
891	123	1	17:00	22:00	f	30
892	123	2	17:00	22:00	t	30
893	123	3	17:00	22:00	t	30
894	123	4	17:00	22:00	t	30
895	123	5	17:00	22:00	t	30
896	123	6	11:00	22:00	t	30
897	124	0	11:00	22:00	t	30
898	124	1	17:00	22:00	f	30
899	124	2	17:00	22:00	t	30
900	124	3	17:00	22:00	t	30
901	124	4	17:00	22:00	t	30
902	124	5	17:00	22:00	t	30
903	124	6	11:00	22:00	t	30
904	125	0	11:00	22:00	t	30
905	125	1	17:00	22:00	f	30
906	125	2	17:00	22:00	t	30
907	125	3	17:00	22:00	t	30
908	125	4	17:00	22:00	t	30
909	125	5	17:00	22:00	t	30
910	125	6	11:00	22:00	t	30
911	126	0	11:00	22:00	t	30
912	126	1	17:00	22:00	f	30
913	126	2	17:00	22:00	t	30
914	126	3	17:00	22:00	t	30
915	126	4	17:00	22:00	t	30
916	126	5	17:00	22:00	t	30
917	126	6	11:00	22:00	t	30
918	127	0	11:00	22:00	t	30
919	127	1	17:00	22:00	f	30
920	127	2	17:00	22:00	t	30
921	127	3	17:00	22:00	t	30
922	127	4	17:00	22:00	t	30
923	127	5	17:00	22:00	t	30
924	127	6	11:00	22:00	t	30
925	128	0	11:00	22:00	t	30
926	128	1	17:00	22:00	f	30
927	128	2	17:00	22:00	t	30
928	128	3	17:00	22:00	t	30
929	128	4	17:00	22:00	t	30
930	128	5	17:00	22:00	t	30
931	128	6	11:00	22:00	t	30
932	129	0	11:00	22:00	t	30
933	129	1	17:00	22:00	f	30
934	129	2	17:00	22:00	t	30
935	129	3	17:00	22:00	t	30
936	129	4	17:00	22:00	t	30
937	129	5	17:00	22:00	t	30
938	129	6	11:00	22:00	t	30
939	130	0	11:00	22:00	t	30
940	130	1	17:00	22:00	f	30
941	130	2	17:00	22:00	t	30
942	130	3	17:00	22:00	t	30
943	130	4	17:00	22:00	t	30
944	130	5	17:00	22:00	t	30
945	130	6	11:00	22:00	t	30
946	131	0	11:00	22:00	t	30
947	131	1	17:00	22:00	f	30
948	131	2	17:00	22:00	t	30
949	131	3	17:00	22:00	t	30
950	131	4	17:00	22:00	t	30
951	131	5	17:00	22:00	t	30
952	131	6	11:00	22:00	t	30
953	132	0	11:00	22:00	t	30
954	132	1	17:00	22:00	f	30
955	132	2	17:00	22:00	t	30
956	132	3	17:00	22:00	t	30
957	132	4	17:00	22:00	t	30
958	132	5	17:00	22:00	t	30
959	132	6	11:00	22:00	t	30
960	133	0	11:00	22:00	t	30
961	133	1	17:00	22:00	f	30
962	133	2	17:00	22:00	t	30
963	133	3	17:00	22:00	t	30
964	133	4	17:00	22:00	t	30
965	133	5	17:00	22:00	t	30
966	133	6	11:00	22:00	t	30
967	134	0	11:00	22:00	t	30
968	134	1	17:00	22:00	f	30
969	134	2	17:00	22:00	t	30
970	134	3	17:00	22:00	t	30
971	134	4	17:00	22:00	t	30
972	134	5	17:00	22:00	t	30
973	134	6	11:00	22:00	t	30
974	135	0	11:00	22:00	t	30
975	135	1	17:00	22:00	f	30
976	135	2	17:00	22:00	t	30
977	135	3	17:00	22:00	t	30
978	135	4	17:00	22:00	t	30
979	135	5	17:00	22:00	t	30
980	135	6	11:00	22:00	t	30
981	136	0	11:00	22:00	t	30
982	136	1	17:00	22:00	f	30
983	136	2	17:00	22:00	t	30
984	136	3	17:00	22:00	t	30
985	136	4	17:00	22:00	t	30
986	136	5	17:00	22:00	t	30
987	136	6	11:00	22:00	t	30
988	137	0	11:00	22:00	t	30
989	137	1	17:00	22:00	f	30
990	137	2	17:00	22:00	t	30
991	137	3	17:00	22:00	t	30
992	137	4	17:00	22:00	t	30
993	137	5	17:00	22:00	t	30
994	137	6	11:00	22:00	t	30
995	138	0	11:00	22:00	t	30
996	138	1	17:00	22:00	f	30
997	138	2	17:00	22:00	t	30
998	138	3	17:00	22:00	t	30
999	138	4	17:00	22:00	t	30
1000	138	5	17:00	22:00	t	30
1001	138	6	11:00	22:00	t	30
1002	139	0	11:00	22:00	t	30
1003	139	1	17:00	22:00	f	30
1004	139	2	17:00	22:00	t	30
1005	139	3	17:00	22:00	t	30
1006	139	4	17:00	22:00	t	30
1007	139	5	17:00	22:00	t	30
1008	139	6	11:00	22:00	t	30
1009	140	0	11:00	22:00	t	30
1010	140	1	17:00	22:00	f	30
1011	140	2	17:00	22:00	t	30
1012	140	3	17:00	22:00	t	30
1013	140	4	17:00	22:00	t	30
1014	140	5	17:00	22:00	t	30
1015	140	6	11:00	22:00	t	30
1016	141	0	11:00	22:00	t	30
1017	141	1	17:00	22:00	f	30
1018	141	2	17:00	22:00	t	30
1019	141	3	17:00	22:00	t	30
1020	141	4	17:00	22:00	t	30
1021	141	5	17:00	22:00	t	30
1022	141	6	11:00	22:00	t	30
1023	142	0	11:00	22:00	t	30
1024	142	1	17:00	22:00	f	30
1025	142	2	17:00	22:00	t	30
1026	142	3	17:00	22:00	t	30
1027	142	4	17:00	22:00	t	30
1028	142	5	17:00	22:00	t	30
1029	142	6	11:00	22:00	t	30
1030	143	0	11:00	22:00	t	30
1031	143	1	17:00	22:00	f	30
1032	143	2	17:00	22:00	t	30
1033	143	3	17:00	22:00	t	30
1034	143	4	17:00	22:00	t	30
1035	143	5	17:00	22:00	t	30
1036	143	6	11:00	22:00	t	30
1037	144	0	11:00	22:00	t	30
1038	144	1	17:00	22:00	f	30
1039	144	2	17:00	22:00	t	30
1040	144	3	17:00	22:00	t	30
1041	144	4	17:00	22:00	t	30
1042	144	5	17:00	22:00	t	30
1043	144	6	11:00	22:00	t	30
1044	145	0	11:00	22:00	t	30
1045	145	1	17:00	22:00	f	30
1046	145	2	17:00	22:00	t	30
1047	145	3	17:00	22:00	t	30
1048	145	4	17:00	22:00	t	30
1049	145	5	17:00	22:00	t	30
1050	145	6	11:00	22:00	t	30
1051	146	0	11:00	22:00	t	30
1052	146	1	17:00	22:00	f	30
1053	146	2	17:00	22:00	t	30
1054	146	3	17:00	22:00	t	30
1055	146	4	17:00	22:00	t	30
1056	146	5	17:00	22:00	t	30
1057	146	6	11:00	22:00	t	30
1058	147	0	11:00	22:00	t	30
1059	147	1	17:00	22:00	f	30
1060	147	2	17:00	22:00	t	30
1061	147	3	17:00	22:00	t	30
1062	147	4	17:00	22:00	t	30
1063	147	5	17:00	22:00	t	30
1064	147	6	11:00	22:00	t	30
1065	148	0	11:00	22:00	t	30
1066	148	1	17:00	22:00	f	30
1067	148	2	17:00	22:00	t	30
1068	148	3	17:00	22:00	t	30
1069	148	4	17:00	22:00	t	30
1070	148	5	17:00	22:00	t	30
1071	148	6	11:00	22:00	t	30
1072	149	0	11:00	22:00	t	30
1073	149	1	17:00	22:00	f	30
1074	149	2	17:00	22:00	t	30
1075	149	3	17:00	22:00	t	30
1076	149	4	17:00	22:00	t	30
1077	149	5	17:00	22:00	t	30
1078	149	6	11:00	22:00	t	30
1079	150	0	11:00	22:00	t	30
1080	150	1	17:00	22:00	f	30
1081	150	2	17:00	22:00	t	30
1082	150	3	17:00	22:00	t	30
1083	150	4	17:00	22:00	t	30
1084	150	5	17:00	22:00	t	30
1085	150	6	11:00	22:00	t	30
1086	151	0	11:00	22:00	t	30
1087	151	1	17:00	22:00	f	30
1088	151	2	17:00	22:00	t	30
1089	151	3	17:00	22:00	t	30
1090	151	4	17:00	22:00	t	30
1091	151	5	17:00	22:00	t	30
1092	151	6	11:00	22:00	t	30
1093	152	0	11:00	22:00	t	30
1094	152	1	17:00	22:00	f	30
1095	152	2	17:00	22:00	t	30
1096	152	3	17:00	22:00	t	30
1097	152	4	17:00	22:00	t	30
1098	152	5	17:00	22:00	t	30
1099	152	6	11:00	22:00	t	30
1100	153	0	11:00	22:00	t	30
1101	153	1	17:00	22:00	f	30
1102	153	2	17:00	22:00	t	30
1103	153	3	17:00	22:00	t	30
1104	153	4	17:00	22:00	t	30
1105	153	5	17:00	22:00	t	30
1106	153	6	11:00	22:00	t	30
1108	154	1	11:00	22:00	t	30
1110	154	3	11:00	22:00	t	30
1112	154	5	11:00	23:00	t	30
1114	155	0	10:00	23:00	t	30
1116	155	2	11:00	22:00	t	30
1118	155	4	11:00	22:00	t	30
1120	155	6	10:00	23:00	t	30
1122	156	1	11:00	22:00	t	30
1124	156	3	11:00	22:00	t	30
1126	156	5	11:00	23:00	t	30
1128	157	0	10:00	23:00	t	30
1130	157	2	11:00	22:00	t	30
1132	157	4	11:00	22:00	t	30
1134	157	6	10:00	23:00	t	30
1136	158	1	11:00	22:00	t	30
1138	158	3	11:00	22:00	t	30
1140	158	5	11:00	23:00	t	30
1142	159	0	10:00	23:00	t	30
1144	159	2	11:00	22:00	t	30
1146	159	4	11:00	22:00	t	30
1148	159	6	10:00	23:00	t	30
1150	160	1	11:00	22:00	t	30
1152	160	3	11:00	22:00	t	30
1154	160	5	11:00	23:00	t	30
1156	161	0	10:00	23:00	t	30
1158	161	2	11:00	22:00	t	30
1160	161	4	11:00	22:00	t	30
1162	161	6	10:00	23:00	t	30
1164	162	1	11:00	22:00	t	30
1166	162	3	11:00	22:00	t	30
1168	162	5	11:00	23:00	t	30
1170	163	0	10:00	23:00	t	30
1172	163	2	11:00	22:00	t	30
1174	163	4	11:00	22:00	t	30
1176	163	6	10:00	23:00	t	30
1177	164	0	10:00	23:00	t	30
1178	164	1	11:00	22:00	t	30
1179	164	2	11:00	22:00	t	30
1180	164	3	11:00	22:00	t	30
1181	164	4	11:00	22:00	t	30
1182	164	5	11:00	23:00	t	30
1183	164	6	10:00	23:00	t	30
1184	165	0	10:00	23:00	t	30
1185	165	1	11:00	22:00	t	30
1186	165	2	11:00	22:00	t	30
1187	165	3	11:00	22:00	t	30
1188	165	4	11:00	22:00	t	30
1189	165	5	11:00	23:00	t	30
1190	165	6	10:00	23:00	t	30
1191	166	0	10:00	23:00	t	30
1192	166	1	11:00	22:00	t	30
1193	166	2	11:00	22:00	t	30
1194	166	3	11:00	22:00	t	30
1195	166	4	11:00	22:00	t	30
1196	166	5	11:00	23:00	t	30
1197	166	6	10:00	23:00	t	30
1198	167	0	10:00	23:00	t	30
1199	167	1	11:00	22:00	t	30
1200	167	2	11:00	22:00	t	30
1201	167	3	11:00	22:00	t	30
1202	167	4	11:00	22:00	t	30
1203	167	5	11:00	23:00	t	30
1204	167	6	10:00	23:00	t	30
1205	168	0	10:00	23:00	t	30
1206	168	1	11:00	22:00	t	30
1207	168	2	11:00	22:00	t	30
1208	168	3	11:00	22:00	t	30
1209	168	4	11:00	22:00	t	30
1210	168	5	11:00	23:00	t	30
1211	168	6	10:00	23:00	t	30
1212	169	0	10:00	23:00	t	30
1213	169	1	11:00	22:00	t	30
1214	169	2	11:00	22:00	t	30
1215	169	3	11:00	22:00	t	30
1216	169	4	11:00	22:00	t	30
1217	169	5	11:00	23:00	t	30
1218	169	6	10:00	23:00	t	30
1219	170	0	10:00	23:00	t	30
1220	170	1	11:00	22:00	t	30
1221	170	2	11:00	22:00	t	30
1222	170	3	11:00	22:00	t	30
1223	170	4	11:00	22:00	t	30
1224	170	5	11:00	23:00	t	30
1225	170	6	10:00	23:00	t	30
1226	171	0	10:00	23:00	t	30
1227	171	1	11:00	22:00	t	30
1228	171	2	11:00	22:00	t	30
1229	171	3	11:00	22:00	t	30
1230	171	4	11:00	22:00	t	30
1231	171	5	11:00	23:00	t	30
1232	171	6	10:00	23:00	t	30
1233	172	0	10:00	23:00	t	30
1234	172	1	11:00	22:00	t	30
1235	172	2	11:00	22:00	t	30
1236	172	3	11:00	22:00	t	30
1237	172	4	11:00	22:00	t	30
1238	172	5	11:00	23:00	t	30
1239	172	6	10:00	23:00	t	30
1240	173	0	10:00	23:00	t	30
1241	173	1	11:00	22:00	t	30
1242	173	2	11:00	22:00	t	30
1243	173	3	11:00	22:00	t	30
1244	173	4	11:00	22:00	t	30
1245	173	5	11:00	23:00	t	30
1246	173	6	10:00	23:00	t	30
1247	174	0	10:00	23:00	t	30
1248	174	1	11:00	22:00	t	30
1249	174	2	11:00	22:00	t	30
1250	174	3	11:00	22:00	t	30
1251	174	4	11:00	22:00	t	30
1252	174	5	11:00	23:00	t	30
1253	174	6	10:00	23:00	t	30
1254	175	0	10:00	23:00	t	30
1255	175	1	11:00	22:00	t	30
1256	175	2	11:00	22:00	t	30
1257	175	3	11:00	22:00	t	30
1258	175	4	11:00	22:00	t	30
1259	175	5	11:00	23:00	t	30
1260	175	6	10:00	23:00	t	30
1261	176	0	10:00	23:00	t	30
1262	176	1	11:00	22:00	t	30
1263	176	2	11:00	22:00	t	30
1264	176	3	11:00	22:00	t	30
1265	176	4	11:00	22:00	t	30
1266	176	5	11:00	23:00	t	30
1267	176	6	10:00	23:00	t	30
1268	177	0	10:00	23:00	t	30
1269	177	1	11:00	22:00	t	30
1270	177	2	11:00	22:00	t	30
1271	177	3	11:00	22:00	t	30
1272	177	4	11:00	22:00	t	30
1273	177	5	11:00	23:00	t	30
1274	177	6	10:00	23:00	t	30
1275	178	0	10:00	23:00	t	30
1276	178	1	11:00	22:00	t	30
1277	178	2	11:00	22:00	t	30
1278	178	3	11:00	22:00	t	30
1279	178	4	11:00	22:00	t	30
1280	178	5	11:00	23:00	t	30
1281	178	6	10:00	23:00	t	30
1282	179	0	10:00	23:00	t	30
1283	179	1	11:00	22:00	t	30
1284	179	2	11:00	22:00	t	30
1285	179	3	11:00	22:00	t	30
1286	179	4	11:00	22:00	t	30
1287	179	5	11:00	23:00	t	30
1288	179	6	10:00	23:00	t	30
1289	180	0	10:00	23:00	t	30
1290	180	1	11:00	22:00	t	30
1291	180	2	11:00	22:00	t	30
1292	180	3	11:00	22:00	t	30
1293	180	4	11:00	22:00	t	30
1294	180	5	11:00	23:00	t	30
1295	180	6	10:00	23:00	t	30
1296	181	0	10:00	23:00	t	30
1297	181	1	11:00	22:00	t	30
1298	181	2	11:00	22:00	t	30
1299	181	3	11:00	22:00	t	30
1300	181	4	11:00	22:00	t	30
1301	181	5	11:00	23:00	t	30
1302	181	6	10:00	23:00	t	30
1303	182	0	10:00	23:00	t	30
1304	182	1	11:00	22:00	t	30
1305	182	2	11:00	22:00	t	30
1306	182	3	11:00	22:00	t	30
1307	182	4	11:00	22:00	t	30
1308	182	5	11:00	23:00	t	30
1309	182	6	10:00	23:00	t	30
1310	183	0	10:00	23:00	t	30
1311	183	1	11:00	22:00	t	30
1312	183	2	11:00	22:00	t	30
1313	183	3	11:00	22:00	t	30
1314	183	4	11:00	22:00	t	30
1315	183	5	11:00	23:00	t	30
1316	183	6	10:00	23:00	t	30
1317	184	0	10:00	23:00	t	30
1318	184	1	11:00	22:00	t	30
1319	184	2	11:00	22:00	t	30
1320	184	3	11:00	22:00	t	30
1321	184	4	11:00	22:00	t	30
1322	184	5	11:00	23:00	t	30
1323	184	6	10:00	23:00	t	30
1324	185	0	10:00	23:00	t	30
1325	185	1	11:00	22:00	t	30
1326	185	2	11:00	22:00	t	30
1327	185	3	11:00	22:00	t	30
1328	185	4	11:00	22:00	t	30
1329	185	5	11:00	23:00	t	30
1330	185	6	10:00	23:00	t	30
1331	186	0	10:00	23:00	t	30
1332	186	1	11:00	22:00	t	30
1333	186	2	11:00	22:00	t	30
1334	186	3	11:00	22:00	t	30
1335	186	4	11:00	22:00	t	30
1336	186	5	11:00	23:00	t	30
1337	186	6	10:00	23:00	t	30
1338	187	0	10:00	23:00	t	30
1339	187	1	11:00	22:00	t	30
1340	187	2	11:00	22:00	t	30
1341	187	3	11:00	22:00	t	30
1342	187	4	11:00	22:00	t	30
1343	187	5	11:00	23:00	t	30
1344	187	6	10:00	23:00	t	30
1345	188	0	10:00	23:00	t	30
1346	188	1	11:00	22:00	t	30
1347	188	2	11:00	22:00	t	30
1348	188	3	11:00	22:00	t	30
1349	188	4	11:00	22:00	t	30
1350	188	5	11:00	23:00	t	30
1351	188	6	10:00	23:00	t	30
\.


--
-- Data for Name: vendor_accounts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.vendor_accounts (id, email, password_hash, restaurant_id, created_at) FROM stdin;
1	vendor1@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	1	2026-04-01 19:25:18.456419
2	vendor2@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	2	2026-04-01 19:25:18.462691
3	vendor3@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	3	2026-04-01 19:25:18.465671
4	vendor4@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	4	2026-04-01 19:25:18.469147
5	vendor5@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	5	2026-04-01 19:25:18.473212
6	vendor6@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	6	2026-04-01 19:25:18.476185
7	vendor7@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	7	2026-04-01 19:25:18.479035
8	vendor8@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	8	2026-04-01 19:25:18.481891
9	vendor9@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	9	2026-04-01 19:25:18.485552
10	vendor10@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	10	2026-04-01 19:25:18.487986
11	vendor11@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	11	2026-04-01 19:25:18.49036
12	vendor12@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	12	2026-04-01 19:25:18.493235
13	vendor13@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	13	2026-04-01 19:25:18.495719
14	vendor14@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	14	2026-04-01 19:25:18.498253
15	vendor15@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	15	2026-04-01 19:25:18.501602
16	vendor16@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	16	2026-04-01 19:25:18.504956
17	vendor17@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	17	2026-04-01 19:25:18.507233
18	vendor18@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	18	2026-04-01 19:25:18.509688
19	vendor19@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	19	2026-04-01 19:25:18.512647
20	vendor20@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	20	2026-04-01 19:25:18.515489
21	vendor21@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	21	2026-04-01 19:25:18.517809
22	vendor22@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	22	2026-04-01 19:25:18.520262
23	vendor23@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	23	2026-04-01 19:25:18.523095
24	vendor24@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	24	2026-04-01 19:25:18.526604
25	vendor25@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	25	2026-04-01 19:25:18.530257
26	vendor26@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	26	2026-04-01 19:25:18.532838
27	vendor27@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	27	2026-04-01 19:25:18.535919
28	vendor28@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	28	2026-04-01 19:25:18.539597
29	vendor29@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	29	2026-04-01 19:25:18.542151
30	vendor30@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	30	2026-04-01 19:25:18.544893
31	vendor31@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	31	2026-04-01 19:25:18.547184
32	vendor32@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	32	2026-04-01 19:25:18.550828
33	vendor33@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	33	2026-04-01 19:25:18.553079
34	vendor34@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	34	2026-04-01 19:25:18.555597
35	vendor35@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	35	2026-04-01 19:25:18.557967
36	vendor36@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	36	2026-04-01 19:25:18.561373
37	vendor37@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	37	2026-04-01 19:25:18.563623
38	vendor38@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	38	2026-04-01 19:25:18.565919
39	vendor39@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	39	2026-04-01 19:25:18.56866
40	vendor40@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	40	2026-04-01 19:25:18.571778
41	vendor41@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	41	2026-04-01 19:25:18.57418
42	vendor42@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	42	2026-04-01 19:25:18.576972
43	vendor43@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	43	2026-04-01 19:25:18.579618
44	vendor44@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	44	2026-04-01 19:25:18.582292
45	vendor45@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	45	2026-04-01 19:25:18.584832
46	vendor46@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	46	2026-04-01 19:25:18.587105
47	vendor47@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	47	2026-04-01 19:25:18.589223
48	vendor48@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	48	2026-04-01 19:25:18.591775
49	vendor49@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	49	2026-04-01 19:25:18.594301
50	vendor50@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	50	2026-04-01 19:25:18.597027
51	vendor51@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	51	2026-04-01 19:25:18.599634
52	vendor52@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	52	2026-04-01 19:25:18.603571
53	vendor53@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	53	2026-04-01 19:25:18.606578
54	vendor54@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	54	2026-04-01 19:25:18.610219
55	vendor55@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	55	2026-04-01 19:25:18.613169
56	vendor56@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	56	2026-04-01 19:25:18.615788
57	vendor57@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	57	2026-04-01 19:25:18.618073
58	vendor58@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	58	2026-04-01 19:25:18.621301
59	vendor59@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	59	2026-04-01 19:25:18.623985
60	vendor60@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	60	2026-04-01 19:25:18.627096
61	vendor61@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	61	2026-04-01 19:25:18.629795
62	vendor62@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	62	2026-04-01 19:25:18.632367
63	vendor63@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	63	2026-04-01 19:25:18.634824
64	vendor64@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	64	2026-04-01 19:25:18.637962
65	vendor65@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	65	2026-04-01 19:25:18.640318
66	vendor66@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	66	2026-04-01 19:25:18.643529
67	vendor67@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	67	2026-04-01 19:25:18.646193
68	vendor68@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	68	2026-04-01 19:25:18.648479
69	vendor69@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	69	2026-04-01 19:25:18.651033
70	vendor70@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	70	2026-04-01 19:25:18.654075
71	vendor71@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	71	2026-04-01 19:25:18.656555
72	vendor72@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	72	2026-04-01 19:25:18.658734
73	vendor73@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	73	2026-04-01 19:25:18.661197
74	vendor74@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	74	2026-04-01 19:25:18.664451
75	vendor75@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	75	2026-04-01 19:25:18.666792
76	vendor76@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	76	2026-04-01 19:25:18.669124
77	vendor77@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	77	2026-04-01 19:25:18.671219
78	vendor78@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	78	2026-04-01 19:25:18.673878
79	vendor79@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	79	2026-04-01 19:25:18.676194
80	vendor80@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	80	2026-04-01 19:25:18.67842
81	vendor81@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	81	2026-04-01 19:25:18.680581
82	vendor82@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	82	2026-04-01 19:25:18.683489
83	vendor83@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	83	2026-04-01 19:25:18.685979
84	vendor84@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	84	2026-04-01 19:25:18.688571
85	vendor85@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	85	2026-04-01 19:25:18.69153
86	vendor86@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	86	2026-04-01 19:25:18.694981
87	vendor87@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	87	2026-04-01 19:25:18.697422
88	vendor88@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	88	2026-04-01 19:25:18.700038
89	vendor89@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	89	2026-04-01 19:25:18.703116
90	vendor90@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	90	2026-04-01 19:25:18.705706
91	vendor91@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	91	2026-04-01 19:25:18.708028
92	vendor92@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	92	2026-04-01 19:25:18.710971
93	vendor93@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	93	2026-04-01 19:25:18.713122
94	vendor94@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	94	2026-04-01 19:25:18.715678
95	vendor95@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	95	2026-04-01 19:25:18.717787
96	vendor96@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	96	2026-04-01 19:25:18.720125
97	vendor97@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	97	2026-04-01 19:25:18.722447
98	vendor98@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	98	2026-04-01 19:25:18.725435
99	vendor99@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	99	2026-04-01 19:25:18.72771
100	vendor100@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	100	2026-04-01 19:25:18.73066
101	vendor101@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	101	2026-04-01 19:25:18.734006
102	vendor102@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	102	2026-04-01 19:25:18.737021
103	vendor103@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	103	2026-04-01 19:25:18.740496
104	vendor104@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	104	2026-04-01 19:25:18.743437
105	vendor105@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	105	2026-04-01 19:25:18.745815
106	vendor106@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	106	2026-04-01 19:25:18.74975
107	vendor107@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	107	2026-04-01 19:25:18.752042
108	vendor108@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	108	2026-04-01 19:25:18.754329
109	vendor109@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	109	2026-04-01 19:25:18.756964
110	vendor110@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	110	2026-04-01 19:25:18.760079
111	vendor111@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	111	2026-04-01 19:25:18.761982
112	vendor112@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	112	2026-04-01 19:25:18.764313
113	vendor113@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	113	2026-04-01 19:25:18.766753
114	vendor114@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	114	2026-04-01 19:25:18.769522
115	vendor115@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	115	2026-04-01 19:25:18.77184
116	vendor116@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	116	2026-04-01 19:25:18.774298
117	vendor117@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	117	2026-04-01 19:25:18.776423
118	vendor118@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	118	2026-04-01 19:25:18.779162
119	vendor119@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	119	2026-04-01 19:25:18.781373
120	vendor120@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	120	2026-04-01 19:25:18.783401
121	vendor121@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	121	2026-04-01 19:25:18.786044
122	vendor122@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	122	2026-04-01 19:25:18.788778
123	vendor123@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	123	2026-04-01 19:25:18.791142
124	vendor124@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	124	2026-04-01 19:25:18.793911
125	vendor125@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	125	2026-04-01 19:25:18.796213
126	vendor126@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	126	2026-04-01 19:25:18.799314
127	vendor127@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	127	2026-04-01 19:25:18.801604
128	vendor128@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	128	2026-04-01 19:25:18.804155
129	vendor129@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	129	2026-04-01 19:25:18.806383
130	vendor130@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	130	2026-04-01 19:25:18.808985
131	vendor131@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	131	2026-04-01 19:25:18.811426
132	vendor132@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	132	2026-04-01 19:25:18.813835
133	vendor133@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	133	2026-04-01 19:25:18.815827
134	vendor134@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	134	2026-04-01 19:25:18.818704
135	vendor135@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	135	2026-04-01 19:25:18.820882
136	vendor136@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	136	2026-04-01 19:25:18.822958
137	vendor137@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	137	2026-04-01 19:25:18.825288
138	vendor138@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	138	2026-04-01 19:25:18.828672
139	vendor139@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	139	2026-04-01 19:25:18.830811
140	vendor140@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	140	2026-04-01 19:25:18.833572
141	vendor141@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	141	2026-04-01 19:25:18.83566
142	vendor142@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	142	2026-04-01 19:25:18.838721
143	vendor143@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	143	2026-04-01 19:25:18.840942
144	vendor144@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	144	2026-04-01 19:25:18.843234
145	vendor145@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	145	2026-04-01 19:25:18.845204
146	vendor146@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	146	2026-04-01 19:25:18.847637
147	vendor147@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	147	2026-04-01 19:25:18.849966
148	vendor148@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	148	2026-04-01 19:25:18.852073
149	vendor149@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	149	2026-04-01 19:25:18.854516
150	vendor150@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	150	2026-04-01 19:25:18.857591
151	vendor151@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	151	2026-04-01 19:25:18.859808
152	vendor152@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	152	2026-04-01 19:25:18.862329
153	vendor153@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	153	2026-04-01 19:25:18.864518
154	vendor154@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	154	2026-04-02 19:16:57.41924
155	vendor155@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	155	2026-04-02 19:17:01.478647
156	vendor156@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	156	2026-04-02 19:17:05.402769
157	vendor157@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	157	2026-04-02 19:17:09.487277
158	vendor158@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	158	2026-04-02 19:17:13.581255
159	vendor159@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	159	2026-04-02 19:17:17.542994
160	vendor160@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	160	2026-04-02 19:17:21.579765
161	vendor161@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	161	2026-04-02 19:17:25.525372
162	vendor162@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	162	2026-04-02 19:17:29.633049
163	vendor163@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	163	2026-04-02 19:17:33.601532
164	vendor164@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	164	2026-04-02 19:17:37.558406
165	vendor165@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	165	2026-04-02 19:17:41.608296
166	vendor166@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	166	2026-04-02 19:17:45.667592
167	vendor167@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	167	2026-04-02 19:17:49.707431
168	vendor168@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	168	2026-04-02 19:17:53.539757
169	vendor169@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	169	2026-04-02 19:17:57.423643
170	vendor170@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	170	2026-04-02 19:18:01.323373
171	vendor171@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	171	2026-04-02 19:18:05.34175
172	vendor172@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	172	2026-04-02 19:18:09.249847
173	vendor173@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	173	2026-04-02 19:18:13.239122
174	vendor174@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	174	2026-04-02 19:18:17.063457
175	vendor175@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	175	2026-04-02 19:18:20.987371
176	vendor176@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	176	2026-04-02 19:18:25.095689
177	vendor177@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	177	2026-04-02 19:18:29.033243
178	vendor178@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	178	2026-04-02 19:18:33.11396
179	vendor179@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	179	2026-04-02 19:18:37.09286
180	vendor180@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	180	2026-04-02 19:18:40.977785
181	vendor181@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	181	2026-04-02 19:18:44.946579
182	vendor182@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	182	2026-04-02 19:18:48.857309
183	vendor183@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	183	2026-04-02 19:18:52.861324
184	vendor184@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	184	2026-04-02 19:18:56.890233
185	vendor185@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	185	2026-04-02 19:19:00.871109
186	vendor186@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	186	2026-04-02 19:19:04.82037
187	vendor187@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	187	2026-04-02 19:19:08.857268
188	vendor188@wny.fyi	$2b$10$m1cYfTGCeAOOZSXXRfXvdeEujTKtRFSJ6ZQtBcC7/P8Vc2Q/V.OY6	188	2026-04-02 19:19:12.786796
\.


--
-- Name: coupons_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.coupons_id_seq', 35, true);


--
-- Name: discount_windows_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.discount_windows_id_seq', 2, true);


--
-- Name: restaurants_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.restaurants_id_seq', 188, true);


--
-- Name: schedules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.schedules_id_seq', 1351, true);


--
-- Name: vendor_accounts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.vendor_accounts_id_seq', 188, true);


--
-- PostgreSQL database dump complete
--

\unrestrict ofSGjinUa55UGzz0FEw14sjMdH23SgZgYeAoIhBMOYwXELdIlsJfjZbcjqreP7t

