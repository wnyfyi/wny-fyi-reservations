import { pgTable, text, serial, integer, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const discountWindowsTable = pgTable("discount_windows", {
  id: serial("id").primaryKey(),
  restaurantId: integer("restaurant_id").notNull(),
  dayOfWeek: integer("day_of_week").notNull(),
  startTime: text("start_time").notNull(),
  endTime: text("end_time").notNull(),
  discountPercent: integer("discount_percent").notNull(),
  label: text("label"),
  isActive: boolean("is_active").notNull().default(true),
});

export const insertDiscountWindowSchema = createInsertSchema(discountWindowsTable).omit({ id: true });
export type InsertDiscountWindow = z.infer<typeof insertDiscountWindowSchema>;
export type DiscountWindow = typeof discountWindowsTable.$inferSelect;
