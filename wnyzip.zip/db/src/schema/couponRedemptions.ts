import { pgTable, text, serial, integer, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const couponRedemptionsTable = pgTable("coupon_redemptions", {
  id: serial("id").primaryKey(),
  couponId: integer("coupon_id").notNull(),
  restaurantId: integer("restaurant_id").notNull(),
  couponCode: text("coupon_code"),
  couponTitle: text("coupon_title").notNull(),
  discountPercent: integer("discount_percent").notNull(),
  customerName: text("customer_name"),
  notes: text("notes"),
  redeemedAt: timestamp("redeemed_at").notNull().defaultNow(),
});

export const insertCouponRedemptionSchema = createInsertSchema(couponRedemptionsTable).omit({ id: true, redeemedAt: true });
export type InsertCouponRedemption = z.infer<typeof insertCouponRedemptionSchema>;
export type CouponRedemption = typeof couponRedemptionsTable.$inferSelect;
