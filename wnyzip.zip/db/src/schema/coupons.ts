import { pgTable, text, serial, integer, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const couponsTable = pgTable("coupons", {
  id: serial("id").primaryKey(),
  restaurantId: integer("restaurant_id").notNull(),
  title: text("title").notNull(),
  code: text("code"),
  description: text("description"),
  dealType: text("deal_type").notNull().default("percent_off"),
  discountPercent: integer("discount_percent"),
  validUntil: text("valid_until"),
  isActive: boolean("is_active").notNull().default(true),
  maxRedemptions: integer("max_redemptions"),
});

export const insertCouponSchema = createInsertSchema(couponsTable).omit({ id: true });
export type InsertCoupon = z.infer<typeof insertCouponSchema>;
export type Coupon = typeof couponsTable.$inferSelect;
