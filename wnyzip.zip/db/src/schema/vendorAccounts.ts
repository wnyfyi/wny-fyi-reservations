import { pgTable, text, serial, integer, timestamp } from "drizzle-orm/pg-core";
import { restaurantsTable } from "./restaurants";

export const vendorAccountsTable = pgTable("vendor_accounts", {
  id: serial("id").primaryKey(),
  email: text("email").notNull().unique(),
  passwordHash: text("password_hash").notNull(),
  restaurantId: integer("restaurant_id").notNull().references(() => restaurantsTable.id),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export type VendorAccount = typeof vendorAccountsTable.$inferSelect;
