import { drizzle } from "drizzle-orm/node-postgres";
import pg from "pg";
import bcrypt from "bcryptjs";
import { restaurantsTable, vendorAccountsTable } from "./schema";

const { Pool } = pg;

if (!process.env.DATABASE_URL) {
  throw new Error("DATABASE_URL must be set.");
}

const pool = new Pool({ connectionString: process.env.DATABASE_URL });
const db = drizzle(pool, { schema: { restaurantsTable, vendorAccountsTable } });

async function seedVendors() {
  console.log("Fetching restaurants...");
  const restaurants = await db.select().from(restaurantsTable);
  console.log(`Found ${restaurants.length} restaurants. Creating vendor accounts...`);

  const DEFAULT_PASSWORD = "buffalo716";
  const hash = await bcrypt.hash(DEFAULT_PASSWORD, 10);

  let created = 0;
  let skipped = 0;

  for (const r of restaurants) {
    const email = `vendor${r.id}@wny.fyi`;
    try {
      await db.insert(vendorAccountsTable).values({
        email,
        passwordHash: hash,
        restaurantId: r.id,
      }).onConflictDoNothing();
      console.log(`  ✓ ${r.name} → ${email}`);
      created++;
    } catch {
      skipped++;
    }
  }

  console.log(`\nDone. Created: ${created}, Skipped: ${skipped}`);
  console.log(`Default password: ${DEFAULT_PASSWORD}`);
  await pool.end();
}

seedVendors().catch((err) => {
  console.error(err);
  process.exit(1);
});
